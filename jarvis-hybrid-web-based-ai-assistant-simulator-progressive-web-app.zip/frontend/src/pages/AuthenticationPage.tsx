// Authentication page with internal Admin and Guest login options
// Admin requires password "omkareshwar", Guest has no password
// Features neon-themed cards with smooth transitions and hover effects
// Handles authentication completely on frontend with localStorage persistence

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Shield, UserCircle } from 'lucide-react';

// Admin password constant (hardcoded as per specification)
const ADMIN_PASSWORD = 'omkareshwar';

interface AuthenticationPageProps {
  onLogin: (role: 'admin' | 'guest') => void; // Callback when login succeeds
}

const AuthenticationPage = ({ onLogin }: AuthenticationPageProps) => {
  // Track which login mode user selected (null = selection screen)
  const [selectedMode, setSelectedMode] = useState<'admin' | 'guest' | null>(null);
  
  // Store password input for admin login
  const [password, setPassword] = useState('');
  
  // Loading state during login process
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Handle admin login with password validation
  const handleAdminLogin = async () => {
    // Validate password before proceeding
    if (password !== ADMIN_PASSWORD) {
      toast.error('Incorrect password');
      return;
    }

    setIsLoggingIn(true);
    
    // Simulate brief loading for better UX
    setTimeout(() => {
      // Trigger login callback with admin role
      onLogin('admin');
      setIsLoggingIn(false);
    }, 500);
  };

  // Handle guest login (no password required)
  const handleGuestLogin = async () => {
    setIsLoggingIn(true);
    
    // Simulate brief loading for better UX
    setTimeout(() => {
      // Trigger login callback with guest role
      onLogin('guest');
      setIsLoggingIn(false);
    }, 500);
  };

  // Show mode selection screen (Admin vs Guest)
  if (selectedMode === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-accent/10 p-4">
        <div className="w-full max-w-4xl">
          {/* Header with JARVIS logo and title */}
          <div className="text-center mb-12">
            <img 
              src="/assets/generated/jarvis-logo-transparent.dim_200x200.png" 
              alt="JARVIS" 
              className="w-32 h-32 mx-auto mb-6 animate-pulse" 
            />
            <h1 className="text-4xl font-bold text-primary neon-text mb-2">Om's JARVIS</h1>
            <p className="text-muted-foreground text-lg">AI Voice Assistant</p>
          </div>

          {/* Two-column grid for Admin and Guest cards */}
          <div className="grid md:grid-cols-2 gap-6">
            {/* Admin Login Card */}
            <Card 
              className="border-primary/30 bg-card/80 backdrop-blur-sm hover:border-primary/60 transition-all cursor-pointer group"
              onClick={() => setSelectedMode('admin')}
            >
              <CardHeader className="text-center">
                {/* Shield icon with hover effect */}
                <div className="mx-auto mb-4 w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <Shield className="w-10 h-10 text-primary" />
                </div>
                <CardTitle className="text-2xl text-primary">Admin</CardTitle>
                <CardDescription>Full access with source code view</CardDescription>
              </CardHeader>
              <CardContent>
                {/* List of admin features */}
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Access source code</li>
                  <li>• Full system control</li>
                  <li>• Advanced features</li>
                </ul>
              </CardContent>
            </Card>

            {/* Guest Login Card */}
            <Card 
              className="border-accent/30 bg-card/80 backdrop-blur-sm hover:border-accent/60 transition-all cursor-pointer group"
              onClick={() => setSelectedMode('guest')}
            >
              <CardHeader className="text-center">
                {/* User icon with hover effect */}
                <div className="mx-auto mb-4 w-20 h-20 rounded-full bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                  <UserCircle className="w-10 h-10 text-accent" />
                </div>
                <CardTitle className="text-2xl text-accent">Guest</CardTitle>
                <CardDescription>Quick access without password</CardDescription>
              </CardHeader>
              <CardContent>
                {/* List of guest features */}
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Voice assistant features</li>
                  <li>• Web search & apps</li>
                  <li>• Custom commands</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Show admin password entry screen
  if (selectedMode === 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-accent/10 p-4">
        <Card className="w-full max-w-md border-primary/30 bg-card/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            {/* Shield icon for admin */}
            <div className="mx-auto mb-4 w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
              <Shield className="w-10 h-10 text-primary" />
            </div>
            <CardTitle className="text-2xl text-primary">Admin Login</CardTitle>
            <CardDescription>Enter admin password to continue</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Password input field */}
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAdminLogin()}
                placeholder="Enter admin password"
                className="border-primary/20 focus:border-primary"
                disabled={isLoggingIn}
                autoFocus
              />
            </div>
            {/* Action buttons: Back and Login */}
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setSelectedMode(null)}
                className="flex-1"
                disabled={isLoggingIn}
              >
                Back
              </Button>
              <Button
                onClick={handleAdminLogin}
                className="flex-1 bg-primary hover:bg-primary/90"
                disabled={isLoggingIn}
              >
                {isLoggingIn ? 'Logging in...' : 'Login'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show guest confirmation screen
  if (selectedMode === 'guest') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-accent/10 p-4">
        <Card className="w-full max-w-md border-accent/30 bg-card/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            {/* User icon for guest */}
            <div className="mx-auto mb-4 w-20 h-20 rounded-full bg-accent/10 flex items-center justify-center">
              <UserCircle className="w-10 h-10 text-accent" />
            </div>
            <CardTitle className="text-2xl text-accent">Guest Access</CardTitle>
            <CardDescription>Continue as guest user</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Description of guest features */}
            <p className="text-sm text-muted-foreground text-center">
              You'll have access to all voice assistant features including web search, app launching, and custom commands.
            </p>
            {/* Action buttons: Back and Continue */}
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setSelectedMode(null)}
                className="flex-1"
                disabled={isLoggingIn}
              >
                Back
              </Button>
              <Button
                onClick={handleGuestLogin}
                className="flex-1 bg-accent hover:bg-accent/90"
                disabled={isLoggingIn}
              >
                {isLoggingIn ? 'Logging in...' : 'Continue'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Return null if no mode is matched (should never happen)
  return null;
};

export default AuthenticationPage;
