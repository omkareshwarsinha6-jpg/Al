// Background clock service with alarm, reminder, and countdown timer functionality
// Runs continuously with persistent storage and pleasant beep sounds

export interface Alarm {
  id: string;
  time: string; // HH:MM format
  label?: string;
  enabled: boolean;
  timestamp: number;
}

export interface Reminder {
  id: string;
  time: string; // HH:MM format
  message: string;
  enabled: boolean;
  timestamp: number;
  isTriggered?: boolean;
  beepIntervalId?: number;
}

export class BackgroundClock {
  private static instance: BackgroundClock | null = null;
  private intervalId: NodeJS.Timeout | null = null;
  private alarms: Alarm[] = [];
  private reminders: Reminder[] = [];
  private listeners: Array<(time: string) => void> = [];
  private alarmListeners: Array<(alarm: Alarm) => void> = [];
  private reminderListeners: Array<(reminder: Reminder) => void> = [];
  private countdownListeners: Array<(reminder: Reminder, countdown: { hours: number; minutes: number; seconds: number }) => void> = [];
  private audioContext: AudioContext | null = null;
  private isRunning = false;
  private beepIntervals: Map<string, number> = new Map();

  private constructor() {
    this.loadFromStorage();
    this.initAudioContext();
  }

  static getInstance(): BackgroundClock {
    if (!BackgroundClock.instance) {
      BackgroundClock.instance = new BackgroundClock();
    }
    return BackgroundClock.instance;
  }

  // Initialize audio context for beep sounds
  private initAudioContext(): void {
    try {
      if (typeof window !== 'undefined' && 'AudioContext' in window) {
        this.audioContext = new AudioContext();
      }
    } catch (error) {
      console.error('Error initializing audio context:', error);
    }
  }

  // Play pleasant beep sound
  playBeep(): void {
    if (!this.audioContext) return;

    try {
      const oscillator = this.audioContext.createOscillator();
      const gainNode = this.audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(this.audioContext.destination);

      oscillator.frequency.value = 800;
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.3, this.audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.5);

      oscillator.start(this.audioContext.currentTime);
      oscillator.stop(this.audioContext.currentTime + 0.5);
    } catch (error) {
      console.error('Error playing beep:', error);
    }
  }

  // Load alarms and reminders from localStorage
  private loadFromStorage(): void {
    try {
      const storedAlarms = localStorage.getItem('jarvis_alarms');
      const storedReminders = localStorage.getItem('jarvis_reminders');

      if (storedAlarms) {
        this.alarms = JSON.parse(storedAlarms);
      }
      if (storedReminders) {
        this.reminders = JSON.parse(storedReminders);
      }
    } catch (error) {
      console.error('Error loading from storage:', error);
    }
  }

  // Save alarms and reminders to localStorage
  private saveToStorage(): void {
    try {
      localStorage.setItem('jarvis_alarms', JSON.stringify(this.alarms));
      localStorage.setItem('jarvis_reminders', JSON.stringify(this.reminders));
    } catch (error) {
      console.error('Error saving to storage:', error);
    }
  }

  // Start the background clock
  start(): void {
    if (this.isRunning) return;

    this.isRunning = true;
    this.intervalId = setInterval(() => {
      this.tick();
    }, 1000);
  }

  // Stop the background clock
  stop(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isRunning = false;
    
    // Stop all beep intervals
    this.beepIntervals.forEach((intervalId) => {
      clearInterval(intervalId);
    });
    this.beepIntervals.clear();
  }

  // Clock tick - check alarms, reminders, and update countdowns
  private tick(): void {
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    // Notify time listeners
    this.listeners.forEach(listener => {
      try {
        listener(currentTime);
      } catch (error) {
        console.error('Error in time listener:', error);
      }
    });

    // Check alarms
    this.alarms.forEach(alarm => {
      if (alarm.enabled && alarm.time === currentTime) {
        this.triggerAlarm(alarm);
      }
    });

    // Check reminders and update countdowns
    this.reminders.forEach(reminder => {
      if (reminder.enabled) {
        const countdown = this.calculateCountdown(reminder.time);
        
        // Notify countdown listeners
        this.countdownListeners.forEach(listener => {
          try {
            listener(reminder, countdown);
          } catch (error) {
            console.error('Error in countdown listener:', error);
          }
        });
        
        // Trigger reminder if time matches
        if (reminder.time === currentTime && !reminder.isTriggered) {
          this.triggerReminder(reminder);
        }
      }
    });
  }

  // Calculate countdown to target time
  private calculateCountdown(targetTime: string): { hours: number; minutes: number; seconds: number } {
    const now = new Date();
    const [targetHours, targetMinutes] = targetTime.split(':').map(Number);
    
    const target = new Date();
    target.setHours(targetHours, targetMinutes, 0, 0);
    
    // If target time is in the past today, assume it's for tomorrow
    if (target <= now) {
      target.setDate(target.getDate() + 1);
    }
    
    const diff = target.getTime() - now.getTime();
    const totalSeconds = Math.floor(diff / 1000);
    
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    return { hours, minutes, seconds };
  }

  // Trigger alarm
  private triggerAlarm(alarm: Alarm): void {
    this.playBeep();
    this.alarmListeners.forEach(listener => {
      try {
        listener(alarm);
      } catch (error) {
        console.error('Error in alarm listener:', error);
      }
    });

    // Disable one-time alarm
    alarm.enabled = false;
    this.saveToStorage();
  }

  // Trigger reminder with repeating beep
  private triggerReminder(reminder: Reminder): void {
    reminder.isTriggered = true;
    this.playBeep();
    
    // Start repeating beep every 3 seconds
    const beepInterval = window.setInterval(() => {
      this.playBeep();
    }, 3000);
    
    this.beepIntervals.set(reminder.id, beepInterval);
    
    this.reminderListeners.forEach(listener => {
      try {
        listener(reminder);
      } catch (error) {
        console.error('Error in reminder listener:', error);
      }
    });
    
    this.saveToStorage();
  }

  // Stop reminder beep
  stopReminderBeep(reminderId: string): void {
    const beepInterval = this.beepIntervals.get(reminderId);
    if (beepInterval) {
      clearInterval(beepInterval);
      this.beepIntervals.delete(reminderId);
    }
    
    // Disable the reminder
    const reminder = this.reminders.find(r => r.id === reminderId);
    if (reminder) {
      reminder.enabled = false;
      reminder.isTriggered = false;
      this.saveToStorage();
    }
  }

  // Get current time
  getCurrentTime(): string {
    const now = new Date();
    return now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  }

  // Parse time string to HH:MM format
  private parseTime(timeStr: string): string | null {
    const normalized = timeStr.toLowerCase().trim();
    
    // Handle "8 AM", "8:30 PM", etc.
    const match = normalized.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/);
    if (!match) return null;

    let hours = parseInt(match[1]);
    const minutes = match[2] ? parseInt(match[2]) : 0;
    const period = match[3];

    if (period === 'pm' && hours < 12) hours += 12;
    if (period === 'am' && hours === 12) hours = 0;

    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  }

  // Set alarm
  setAlarm(timeStr: string, label?: string): Alarm | null {
    const time = this.parseTime(timeStr);
    if (!time) return null;

    const alarm: Alarm = {
      id: `alarm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      time,
      label,
      enabled: true,
      timestamp: Date.now(),
    };

    this.alarms.push(alarm);
    this.saveToStorage();
    return alarm;
  }

  // Set reminder
  setReminder(timeStr: string, message: string): Reminder | null {
    const time = this.parseTime(timeStr);
    if (!time) return null;

    const reminder: Reminder = {
      id: `reminder_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      time,
      message,
      enabled: true,
      timestamp: Date.now(),
      isTriggered: false,
    };

    this.reminders.push(reminder);
    this.saveToStorage();
    return reminder;
  }

  // Get all alarms
  getAlarms(): Alarm[] {
    return [...this.alarms];
  }

  // Get all reminders
  getReminders(): Reminder[] {
    return [...this.reminders];
  }

  // Delete alarm
  deleteAlarm(id: string): void {
    this.alarms = this.alarms.filter(a => a.id !== id);
    this.saveToStorage();
  }

  // Delete reminder
  deleteReminder(id: string): void {
    this.stopReminderBeep(id);
    this.reminders = this.reminders.filter(r => r.id !== id);
    this.saveToStorage();
  }

  // Toggle alarm
  toggleAlarm(id: string): void {
    const alarm = this.alarms.find(a => a.id === id);
    if (alarm) {
      alarm.enabled = !alarm.enabled;
      this.saveToStorage();
    }
  }

  // Toggle reminder
  toggleReminder(id: string): void {
    const reminder = this.reminders.find(r => r.id === id);
    if (reminder) {
      reminder.enabled = !reminder.enabled;
      if (!reminder.enabled) {
        this.stopReminderBeep(id);
      }
      this.saveToStorage();
    }
  }

  // Add time listener
  addTimeListener(callback: (time: string) => void): void {
    this.listeners.push(callback);
  }

  // Add alarm listener
  addAlarmListener(callback: (alarm: Alarm) => void): void {
    this.alarmListeners.push(callback);
  }

  // Add reminder listener
  addReminderListener(callback: (reminder: Reminder) => void): void {
    this.reminderListeners.push(callback);
  }

  // Add countdown listener
  addCountdownListener(callback: (reminder: Reminder, countdown: { hours: number; minutes: number; seconds: number }) => void): void {
    this.countdownListeners.push(callback);
  }

  // Remove listeners
  removeTimeListener(callback: (time: string) => void): void {
    this.listeners = this.listeners.filter(l => l !== callback);
  }

  removeAlarmListener(callback: (alarm: Alarm) => void): void {
    this.alarmListeners = this.alarmListeners.filter(l => l !== callback);
  }

  removeReminderListener(callback: (reminder: Reminder) => void): void {
    this.reminderListeners = this.reminderListeners.filter(l => l !== callback);
  }

  removeCountdownListener(callback: (reminder: Reminder, countdown: { hours: number; minutes: number; seconds: number }) => void): void {
    this.countdownListeners = this.countdownListeners.filter(l => l !== callback);
  }
}
