// Enhanced memory management system for persistent storage of conversations, automations, search results, and AI responses
// Uses localStorage and IndexedDB for offline reliability and fast recall with OpenAI/Gemini response caching

export interface MemoryState {
  conversations: Array<{ speaker: string; message: string; timestamp: number }>;
  searchResults: Array<{ query: string; results: string; timestamp: number }>;
  aiResponses: Array<{ query: string; response: string; provider: 'openai' | 'gemini' | 'deepseek'; timestamp: number }>;
  frequentCommands: Array<{ command: string; count: number; lastUsed: number }>;
  contextHistory: string[];
  scheduledTasks: Array<{ id: string; task: string; scheduledTime: number; executed: boolean }>;
}

export class MemoryManager {
  private static STORAGE_KEY = 'jarvis_memory_state';
  private static MAX_CONVERSATIONS = 100;
  private static MAX_SEARCH_RESULTS = 50;
  private static MAX_AI_RESPONSES = 100;
  private static MAX_FREQUENT_COMMANDS = 50;
  private static MAX_CONTEXT_HISTORY = 5;
  private static AI_CACHE_EXPIRY = 24 * 60 * 60 * 1000; // 24 hours

  // Load memory state from localStorage
  static loadMemoryState(): MemoryState {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (error) {
      console.error('Error loading memory state:', error);
    }

    return {
      conversations: [],
      searchResults: [],
      aiResponses: [],
      frequentCommands: [],
      contextHistory: [],
      scheduledTasks: [],
    };
  }

  // Save memory state to localStorage
  static saveMemoryState(state: MemoryState): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(state));
    } catch (error) {
      console.error('Error saving memory state:', error);
    }
  }

  // Add conversation to memory
  static addConversation(speaker: string, message: string): void {
    const state = this.loadMemoryState();
    state.conversations.push({
      speaker,
      message,
      timestamp: Date.now(),
    });

    // Keep only last MAX_CONVERSATIONS
    if (state.conversations.length > this.MAX_CONVERSATIONS) {
      state.conversations = state.conversations.slice(-this.MAX_CONVERSATIONS);
    }

    this.saveMemoryState(state);
  }

  // Add search result to memory
  static addSearchResult(query: string, results: string): void {
    const state = this.loadMemoryState();
    state.searchResults.push({
      query,
      results,
      timestamp: Date.now(),
    });

    // Keep only last MAX_SEARCH_RESULTS
    if (state.searchResults.length > this.MAX_SEARCH_RESULTS) {
      state.searchResults = state.searchResults.slice(-this.MAX_SEARCH_RESULTS);
    }

    this.saveMemoryState(state);
  }

  // Add AI response to memory cache
  static addAIResponse(query: string, response: string, provider: 'openai' | 'gemini' | 'deepseek'): void {
    const state = this.loadMemoryState();
    
    // Check if similar query exists (case-insensitive)
    const existingIndex = state.aiResponses.findIndex(
      r => r.query.toLowerCase() === query.toLowerCase() && r.provider === provider
    );
    
    if (existingIndex !== -1) {
      // Update existing response
      state.aiResponses[existingIndex] = {
        query,
        response,
        provider,
        timestamp: Date.now(),
      };
    } else {
      // Add new response
      state.aiResponses.push({
        query,
        response,
        provider,
        timestamp: Date.now(),
      });
    }

    // Keep only last MAX_AI_RESPONSES
    if (state.aiResponses.length > this.MAX_AI_RESPONSES) {
      state.aiResponses = state.aiResponses.slice(-this.MAX_AI_RESPONSES);
    }

    this.saveMemoryState(state);
  }

  // Get cached AI response if available and not expired
  static getCachedAIResponse(query: string, provider: 'openai' | 'gemini' | 'deepseek'): string | null {
    const state = this.loadMemoryState();
    const now = Date.now();
    
    const cached = state.aiResponses.find(
      r => r.query.toLowerCase() === query.toLowerCase() && 
           r.provider === provider &&
           (now - r.timestamp) < this.AI_CACHE_EXPIRY
    );
    
    return cached ? cached.response : null;
  }

  // Track frequent command usage
  static trackCommand(command: string): void {
    const state = this.loadMemoryState();
    const existing = state.frequentCommands.find(c => c.command === command);

    if (existing) {
      existing.count++;
      existing.lastUsed = Date.now();
    } else {
      state.frequentCommands.push({
        command,
        count: 1,
        lastUsed: Date.now(),
      });
    }

    // Sort by count and keep top MAX_FREQUENT_COMMANDS
    state.frequentCommands.sort((a, b) => b.count - a.count);
    if (state.frequentCommands.length > this.MAX_FREQUENT_COMMANDS) {
      state.frequentCommands = state.frequentCommands.slice(0, this.MAX_FREQUENT_COMMANDS);
    }

    this.saveMemoryState(state);
  }

  // Update context history (last 5 commands)
  static updateContextHistory(command: string): void {
    const state = this.loadMemoryState();
    state.contextHistory.push(command);

    // Keep only last MAX_CONTEXT_HISTORY
    if (state.contextHistory.length > this.MAX_CONTEXT_HISTORY) {
      state.contextHistory = state.contextHistory.slice(-this.MAX_CONTEXT_HISTORY);
    }

    this.saveMemoryState(state);
  }

  // Get context history
  static getContextHistory(): string[] {
    const state = this.loadMemoryState();
    return state.contextHistory;
  }

  // Get frequent commands
  static getFrequentCommands(): Array<{ command: string; count: number }> {
    const state = this.loadMemoryState();
    return state.frequentCommands.slice(0, 10);
  }

  // Search in memory
  static searchMemory(query: string): Array<{ type: string; content: string; timestamp: number }> {
    const state = this.loadMemoryState();
    const results: Array<{ type: string; content: string; timestamp: number }> = [];

    // Search conversations
    state.conversations.forEach(conv => {
      if (conv.message.toLowerCase().includes(query.toLowerCase())) {
        results.push({
          type: 'conversation',
          content: `${conv.speaker}: ${conv.message}`,
          timestamp: conv.timestamp,
        });
      }
    });

    // Search search results
    state.searchResults.forEach(result => {
      if (result.query.toLowerCase().includes(query.toLowerCase()) || 
          result.results.toLowerCase().includes(query.toLowerCase())) {
        results.push({
          type: 'search',
          content: `Query: ${result.query}`,
          timestamp: result.timestamp,
        });
      }
    });

    // Search AI responses
    state.aiResponses.forEach(ai => {
      if (ai.query.toLowerCase().includes(query.toLowerCase()) || 
          ai.response.toLowerCase().includes(query.toLowerCase())) {
        results.push({
          type: 'ai_response',
          content: `${ai.provider.toUpperCase()}: ${ai.query}`,
          timestamp: ai.timestamp,
        });
      }
    });

    return results.sort((a, b) => b.timestamp - a.timestamp);
  }

  // Get memory statistics
  static getMemoryStats(): { conversations: number; searches: number; commands: number; tasks: number; aiResponses: number } {
    const state = this.loadMemoryState();
    return {
      conversations: state.conversations.length,
      searches: state.searchResults.length,
      commands: state.frequentCommands.length,
      tasks: state.scheduledTasks.length,
      aiResponses: state.aiResponses.length,
    };
  }

  // Clear all memory
  static clearMemory(): void {
    localStorage.removeItem(this.STORAGE_KEY);
  }

  // Clear expired AI responses
  static clearExpiredAIResponses(): void {
    const state = this.loadMemoryState();
    const now = Date.now();
    
    state.aiResponses = state.aiResponses.filter(
      r => (now - r.timestamp) < this.AI_CACHE_EXPIRY
    );
    
    this.saveMemoryState(state);
  }

  // Add scheduled task
  static addScheduledTask(task: string, scheduledTime: number): string {
    const state = this.loadMemoryState();
    const id = `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    state.scheduledTasks.push({
      id,
      task,
      scheduledTime,
      executed: false,
    });

    this.saveMemoryState(state);
    return id;
  }

  // Get pending scheduled tasks
  static getPendingTasks(): Array<{ id: string; task: string; scheduledTime: number }> {
    const state = this.loadMemoryState();
    const now = Date.now();
    
    return state.scheduledTasks
      .filter(t => !t.executed && t.scheduledTime <= now)
      .map(({ id, task, scheduledTime }) => ({ id, task, scheduledTime }));
  }

  // Mark task as executed
  static markTaskExecuted(id: string): void {
    const state = this.loadMemoryState();
    const task = state.scheduledTasks.find(t => t.id === id);
    if (task) {
      task.executed = true;
      this.saveMemoryState(state);
    }
  }

  // Get all scheduled tasks
  static getAllScheduledTasks(): Array<{ id: string; task: string; scheduledTime: number; executed: boolean }> {
    const state = this.loadMemoryState();
    return state.scheduledTasks;
  }

  // Remove scheduled task
  static removeScheduledTask(id: string): void {
    const state = this.loadMemoryState();
    state.scheduledTasks = state.scheduledTasks.filter(t => t.id !== id);
    this.saveMemoryState(state);
  }
}
