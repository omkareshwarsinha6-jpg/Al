// Training dataset with 95+ structured intent-response mappings with duplicate removal and slot matching
// Provides normalized command recognition with parameterized support for dynamic queries

export interface TrainingEntry {
  id: number;
  intent: string;
  query: string;
  response: string;
  action?: {
    type: 'open_app' | 'search' | 'system' | 'time' | 'alarm' | 'reminder' | 'message';
    target?: string;
    params?: Record<string, string>;
  };
}

export const TRAINING_DATASET: TrainingEntry[] = [
  // Greetings (1-10)
  { id: 1, intent: 'greeting', query: 'hello', response: 'Hello! How may I assist you today?' },
  { id: 2, intent: 'greeting', query: 'hi', response: 'Hi there! What can I help you with?' },
  { id: 3, intent: 'greeting', query: 'hey', response: 'Hey! How can I be of service?' },
  { id: 4, intent: 'greeting', query: 'good morning', response: 'Good morning! Ready to assist you.' },
  { id: 5, intent: 'greeting', query: 'good afternoon', response: 'Good afternoon! How may I help?' },
  { id: 6, intent: 'greeting', query: 'good evening', response: 'Good evening! What can I do for you?' },
  { id: 7, intent: 'greeting', query: 'how are you', response: 'I am functioning optimally, thank you for asking!' },
  { id: 8, intent: 'greeting', query: 'whats up', response: 'All systems operational! How can I assist?' },
  { id: 9, intent: 'greeting', query: 'hey jarvis', response: 'Yes sir, I am here. How may I help?' },
  { id: 10, intent: 'greeting', query: 'jarvis', response: 'At your service, sir.' },

  // Time queries (11-15)
  { id: 11, intent: 'time_query', query: 'what time is it', response: 'The current time is {time}', action: { type: 'time' } },
  { id: 12, intent: 'time_query', query: 'whats the time', response: 'It is {time}', action: { type: 'time' } },
  { id: 13, intent: 'time_query', query: 'tell me the time', response: 'The time is {time}', action: { type: 'time' } },
  { id: 14, intent: 'time_query', query: 'current time', response: 'Current time: {time}', action: { type: 'time' } },
  { id: 15, intent: 'time_query', query: 'time please', response: 'The time is {time}', action: { type: 'time' } },

  // Date queries (16-20)
  { id: 16, intent: 'date_query', query: 'what is the date', response: 'Today is {date}' },
  { id: 17, intent: 'date_query', query: 'whats todays date', response: 'Today is {date}' },
  { id: 18, intent: 'date_query', query: 'tell me the date', response: 'The date is {date}' },
  { id: 19, intent: 'date_query', query: 'what day is it', response: 'Today is {date}' },
  { id: 20, intent: 'date_query', query: 'todays date', response: 'Today is {date}' },

  // App opening (21-40)
  { id: 21, intent: 'open_app', query: 'open whatsapp', response: 'Opening WhatsApp', action: { type: 'open_app', target: 'whatsapp' } },
  { id: 22, intent: 'open_app', query: 'open youtube', response: 'Opening YouTube', action: { type: 'open_app', target: 'youtube' } },
  { id: 23, intent: 'open_app', query: 'open instagram', response: 'Opening Instagram', action: { type: 'open_app', target: 'instagram' } },
  { id: 24, intent: 'open_app', query: 'open facebook', response: 'Opening Facebook', action: { type: 'open_app', target: 'facebook' } },
  { id: 25, intent: 'open_app', query: 'open gmail', response: 'Opening Gmail', action: { type: 'open_app', target: 'gmail' } },
  { id: 26, intent: 'open_app', query: 'open chrome', response: 'Opening Chrome', action: { type: 'open_app', target: 'chrome' } },
  { id: 27, intent: 'open_app', query: 'open maps', response: 'Opening Google Maps', action: { type: 'open_app', target: 'maps' } },
  { id: 28, intent: 'open_app', query: 'open spotify', response: 'Opening Spotify', action: { type: 'open_app', target: 'spotify' } },
  { id: 29, intent: 'open_app', query: 'open netflix', response: 'Opening Netflix', action: { type: 'open_app', target: 'netflix' } },
  { id: 30, intent: 'open_app', query: 'open amazon', response: 'Opening Amazon', action: { type: 'open_app', target: 'amazon' } },
  { id: 31, intent: 'open_app', query: 'open telegram', response: 'Opening Telegram', action: { type: 'open_app', target: 'telegram' } },
  { id: 32, intent: 'open_app', query: 'open twitter', response: 'Opening Twitter', action: { type: 'open_app', target: 'twitter' } },
  { id: 33, intent: 'open_app', query: 'open camera', response: 'Opening Camera', action: { type: 'open_app', target: 'camera' } },
  { id: 34, intent: 'open_app', query: 'open settings', response: 'Opening Settings', action: { type: 'open_app', target: 'settings' } },
  { id: 35, intent: 'open_app', query: 'open calculator', response: 'Opening Calculator', action: { type: 'open_app', target: 'calculator' } },
  { id: 36, intent: 'open_app', query: 'open phone', response: 'Opening Phone', action: { type: 'open_app', target: 'phone' } },
  { id: 37, intent: 'open_app', query: 'open messages', response: 'Opening Messages', action: { type: 'open_app', target: 'messages' } },
  { id: 38, intent: 'open_app', query: 'open contacts', response: 'Opening Contacts', action: { type: 'open_app', target: 'contacts' } },
  { id: 39, intent: 'open_app', query: 'open calendar', response: 'Opening Calendar', action: { type: 'open_app', target: 'calendar' } },
  { id: 40, intent: 'open_app', query: 'open photos', response: 'Opening Photos', action: { type: 'open_app', target: 'photos' } },

  // WhatsApp Messaging with corrected intent (41-50)
  { id: 41, intent: 'send_whatsapp_message', query: 'text {message} to {name}', response: 'Sending message', action: { type: 'message', target: 'whatsapp' } },
  { id: 42, intent: 'send_whatsapp_message', query: 'send {message} to {name}', response: 'Sending message', action: { type: 'message', target: 'whatsapp' } },
  { id: 43, intent: 'send_whatsapp_message', query: 'whatsapp {message} to {name}', response: 'Sending message', action: { type: 'message', target: 'whatsapp' } },
  { id: 44, intent: 'send_whatsapp_message', query: 'message {name} {message}', response: 'Sending message', action: { type: 'message', target: 'whatsapp' } },
  { id: 45, intent: 'send_whatsapp_message', query: 'send message {message}', response: 'Sending message', action: { type: 'message', target: 'whatsapp' } },
  { id: 46, intent: 'send_message', query: 'send message to {name}', response: 'Opening WhatsApp', action: { type: 'open_app', target: 'whatsapp' } },
  { id: 47, intent: 'send_message', query: 'message {name}', response: 'Opening WhatsApp', action: { type: 'open_app', target: 'whatsapp' } },
  { id: 48, intent: 'send_message', query: 'whatsapp {name}', response: 'Opening WhatsApp', action: { type: 'open_app', target: 'whatsapp' } },
  { id: 49, intent: 'send_message', query: 'text {name}', response: 'Opening Messages', action: { type: 'open_app', target: 'messages' } },
  { id: 50, intent: 'send_message', query: 'send text to {name}', response: 'Opening Messages', action: { type: 'open_app', target: 'messages' } },

  // Search (51-60)
  { id: 51, intent: 'search', query: 'search {query}', response: 'Searching for {query}', action: { type: 'search' } },
  { id: 52, intent: 'search', query: 'find {query}', response: 'Finding {query}', action: { type: 'search' } },
  { id: 53, intent: 'search', query: 'look up {query}', response: 'Looking up {query}', action: { type: 'search' } },
  { id: 54, intent: 'search', query: 'google {query}', response: 'Searching Google for {query}', action: { type: 'search' } },
  { id: 55, intent: 'search', query: 'search for {query}', response: 'Searching for {query}', action: { type: 'search' } },
  { id: 56, intent: 'search', query: 'what is {query}', response: 'Searching for {query}', action: { type: 'search' } },
  { id: 57, intent: 'search', query: 'who is {query}', response: 'Searching for {query}', action: { type: 'search' } },
  { id: 58, intent: 'search', query: 'where is {query}', response: 'Searching for {query}', action: { type: 'search' } },
  { id: 59, intent: 'search', query: 'when is {query}', response: 'Searching for {query}', action: { type: 'search' } },
  { id: 60, intent: 'search', query: 'how to {query}', response: 'Searching for {query}', action: { type: 'search' } },

  // Alarms (61-70)
  { id: 61, intent: 'set_alarm', query: 'set alarm for {time}', response: 'Setting alarm for {time}', action: { type: 'alarm' } },
  { id: 62, intent: 'set_alarm', query: 'alarm at {time}', response: 'Alarm set for {time}', action: { type: 'alarm' } },
  { id: 63, intent: 'set_alarm', query: 'wake me up at {time}', response: 'Alarm set for {time}', action: { type: 'alarm' } },
  { id: 64, intent: 'set_alarm', query: 'set an alarm for {time}', response: 'Setting alarm for {time}', action: { type: 'alarm' } },
  { id: 65, intent: 'set_alarm', query: 'create alarm {time}', response: 'Alarm created for {time}', action: { type: 'alarm' } },
  { id: 66, intent: 'set_alarm', query: 'alarm for {time}', response: 'Alarm set for {time}', action: { type: 'alarm' } },
  { id: 67, intent: 'set_alarm', query: 'set alarm {time}', response: 'Setting alarm for {time}', action: { type: 'alarm' } },
  { id: 68, intent: 'set_alarm', query: 'alarm me at {time}', response: 'Alarm set for {time}', action: { type: 'alarm' } },
  { id: 69, intent: 'set_alarm', query: 'wake me at {time}', response: 'Alarm set for {time}', action: { type: 'alarm' } },
  { id: 70, intent: 'set_alarm', query: 'set wake up alarm {time}', response: 'Wake up alarm set for {time}', action: { type: 'alarm' } },

  // Reminders (71-80)
  { id: 71, intent: 'set_reminder', query: 'remind me at {time}', response: 'Reminder set for {time}', action: { type: 'reminder' } },
  { id: 72, intent: 'set_reminder', query: 'reminder at {time}', response: 'Reminder set for {time}', action: { type: 'reminder' } },
  { id: 73, intent: 'set_reminder', query: 'set reminder for {time}', response: 'Setting reminder for {time}', action: { type: 'reminder' } },
  { id: 74, intent: 'set_reminder', query: 'remind me to {task} at {time}', response: 'Reminder set for {time}', action: { type: 'reminder' } },
  { id: 75, intent: 'set_reminder', query: 'create reminder {time}', response: 'Reminder created for {time}', action: { type: 'reminder' } },
  { id: 76, intent: 'set_reminder', query: 'reminder for {time}', response: 'Reminder set for {time}', action: { type: 'reminder' } },
  { id: 77, intent: 'set_reminder', query: 'set a reminder at {time}', response: 'Setting reminder for {time}', action: { type: 'reminder' } },
  { id: 78, intent: 'set_reminder', query: 'remind me {time}', response: 'Reminder set for {time}', action: { type: 'reminder' } },
  { id: 79, intent: 'set_reminder', query: 'reminder {time}', response: 'Reminder set for {time}', action: { type: 'reminder' } },
  { id: 80, intent: 'set_reminder', query: 'set reminder {time}', response: 'Setting reminder for {time}', action: { type: 'reminder' } },

  // System actions (81-90)
  { id: 81, intent: 'system_action', query: 'turn on wifi', response: 'Opening WiFi settings', action: { type: 'system', target: 'wifi' } },
  { id: 82, intent: 'system_action', query: 'turn off wifi', response: 'Opening WiFi settings', action: { type: 'system', target: 'wifi' } },
  { id: 83, intent: 'system_action', query: 'enable bluetooth', response: 'Opening Bluetooth settings', action: { type: 'system', target: 'bluetooth' } },
  { id: 84, intent: 'system_action', query: 'disable bluetooth', response: 'Opening Bluetooth settings', action: { type: 'system', target: 'bluetooth' } },
  { id: 85, intent: 'system_action', query: 'turn on bluetooth', response: 'Opening Bluetooth settings', action: { type: 'system', target: 'bluetooth' } },
  { id: 86, intent: 'system_action', query: 'turn off bluetooth', response: 'Opening Bluetooth settings', action: { type: 'system', target: 'bluetooth' } },
  { id: 87, intent: 'system_action', query: 'increase volume', response: 'Volume control simulated', action: { type: 'system', target: 'volume' } },
  { id: 88, intent: 'system_action', query: 'decrease volume', response: 'Volume control simulated', action: { type: 'system', target: 'volume' } },
  { id: 89, intent: 'system_action', query: 'mute', response: 'Muting device', action: { type: 'system', target: 'volume' } },
  { id: 90, intent: 'system_action', query: 'unmute', response: 'Unmuting device', action: { type: 'system', target: 'volume' } },

  // Help & Info (91-100)
  { id: 91, intent: 'help', query: 'help', response: 'I can help you with: opening apps, setting alarms, reminders, searching, and more. Try saying "open YouTube" or "set alarm for 8 AM".' },
  { id: 92, intent: 'help', query: 'what can you do', response: 'I can open 60+ apps, set alarms and reminders, search the web, check time and date, and execute custom automations.' },
  { id: 93, intent: 'help', query: 'help me', response: 'I am here to assist! You can ask me to open apps, set alarms, search, or create automations.' },
  { id: 94, intent: 'help', query: 'commands', response: 'Available commands: open [app], search [query], set alarm for [time], remind me at [time], what time is it, and more.' },
  { id: 95, intent: 'help', query: 'what are your features', response: 'Features: Voice commands, 60+ app launching, alarms, reminders, search, automations, offline mode, and AI integration.' },
  { id: 96, intent: 'thanks', query: 'thank you', response: 'You are welcome, sir!' },
  { id: 97, intent: 'thanks', query: 'thanks', response: 'My pleasure!' },
  { id: 98, intent: 'thanks', query: 'thanks jarvis', response: 'Always happy to help, sir!' },
  { id: 99, intent: 'goodbye', query: 'goodbye', response: 'Goodbye, sir. I will be here when you need me.' },
  { id: 100, intent: 'goodbye', query: 'bye', response: 'Farewell, sir!' },
];

export class TrainingSystem {
  private dataset: TrainingEntry[];
  private intentMap: Map<string, TrainingEntry[]>;
  private uniqueIntents: Set<string>;

  constructor() {
    // Remove duplicates and normalize dataset
    this.dataset = this.removeDuplicates(TRAINING_DATASET);
    this.intentMap = new Map();
    this.uniqueIntents = new Set();
    this.buildIntentMap();
  }

  // Remove duplicate entries based on normalized query
  private removeDuplicates(entries: TrainingEntry[]): TrainingEntry[] {
    const seen = new Map<string, TrainingEntry>();
    
    entries.forEach(entry => {
      const normalizedQuery = this.normalizeQuery(entry.query);
      const key = `${entry.intent}:${normalizedQuery}`;
      
      if (!seen.has(key)) {
        seen.set(key, entry);
      }
    });
    
    return Array.from(seen.values());
  }

  // Build intent map for fast lookup
  private buildIntentMap(): void {
    this.dataset.forEach(entry => {
      const existing = this.intentMap.get(entry.intent) || [];
      this.intentMap.set(entry.intent, [...existing, entry]);
      this.uniqueIntents.add(entry.intent);
    });
  }

  // Normalize query for matching
  private normalizeQuery(query: string): string {
    return query.toLowerCase().trim().replace(/[^\w\s{}]/g, '');
  }

  // Extract parameters from query using slot matching
  private extractParams(query: string, pattern: string): Record<string, string> | null {
    const params: Record<string, string> = {};
    const patternParts = pattern.split(/\{(\w+)\}/);
    const queryNorm = this.normalizeQuery(query);
    
    let regex = '';
    const paramNames: string[] = [];
    
    for (let i = 0; i < patternParts.length; i++) {
      if (i % 2 === 0) {
        // Static text - escape special regex characters
        regex += patternParts[i].replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      } else {
        // Parameter slot - capture any text
        regex += '(.+?)';
        paramNames.push(patternParts[i]);
      }
    }
    
    // Make the regex more flexible for trailing content
    if (!regex.endsWith('$')) {
      regex += '.*';
    }
    
    const match = queryNorm.match(new RegExp('^' + regex + '$', 'i'));
    if (!match) return null;
    
    // Extract captured groups
    for (let i = 0; i < paramNames.length; i++) {
      params[paramNames[i]] = match[i + 1].trim();
    }
    
    return params;
  }

  // Match query to training entry with slot matching support
  matchQuery(query: string): { entry: TrainingEntry; params: Record<string, string> } | null {
    const normalized = this.normalizeQuery(query);
    
    // Try exact match first
    for (const entry of this.dataset) {
      const entryQuery = this.normalizeQuery(entry.query);
      if (normalized === entryQuery) {
        return { entry, params: {} };
      }
    }
    
    // Try parameterized match with slot extraction
    for (const entry of this.dataset) {
      if (entry.query.includes('{')) {
        const params = this.extractParams(query, entry.query);
        if (params) {
          return { entry, params };
        }
      }
    }
    
    // Try partial match for non-parameterized queries
    for (const entry of this.dataset) {
      if (!entry.query.includes('{')) {
        const entryQuery = this.normalizeQuery(entry.query);
        if (normalized.includes(entryQuery) || entryQuery.includes(normalized)) {
          return { entry, params: {} };
        }
      }
    }
    
    return null;
  }

  // Get all entries for an intent
  getEntriesByIntent(intent: string): TrainingEntry[] {
    return this.intentMap.get(intent) || [];
  }

  // Get dataset statistics
  getStats(): { totalEntries: number; uniqueIntents: number; intents: string[] } {
    return {
      totalEntries: this.dataset.length,
      uniqueIntents: this.uniqueIntents.size,
      intents: Array.from(this.uniqueIntents),
    };
  }

  // Validate dataset completeness
  validateDataset(): { valid: boolean; issues: string[] } {
    const issues: string[] = [];
    
    this.dataset.forEach(entry => {
      if (!entry.intent || entry.intent.trim() === '') {
        issues.push(`Entry ${entry.id}: Missing intent`);
      }
      if (!entry.query || entry.query.trim() === '') {
        issues.push(`Entry ${entry.id}: Missing query`);
      }
      if (!entry.response || entry.response.trim() === '') {
        issues.push(`Entry ${entry.id}: Missing response`);
      }
    });
    
    return {
      valid: issues.length === 0,
      issues,
    };
  }
}
