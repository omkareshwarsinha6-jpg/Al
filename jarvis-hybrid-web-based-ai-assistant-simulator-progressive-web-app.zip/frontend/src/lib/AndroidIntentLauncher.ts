// Strict Android intent launcher with local-only app opening and Play Store redirection ban
// Uses intent://#Intent;package=PACKAGE_NAME;end format exclusively with zero external redirections

import { PlayStoreBan } from './PlayStoreBan';

export class AndroidIntentLauncher {
  // Detect if running in Android environment
  static isAndroidEnvironment(): boolean {
    const userAgent = navigator.userAgent.toLowerCase();
    return /android/i.test(userAgent);
  }

  // Detect if running in WebView (APK)
  static isWebView(): boolean {
    const userAgent = navigator.userAgent.toLowerCase();
    return userAgent.includes('wv') || 
           userAgent.includes('webview') ||
           (window as any).Android !== undefined;
  }

  // Generate strict Android intent URL - NO fallbacks, NO redirects, NO Play Store
  static generateStrictIntent(packageName: string): string {
    if (!this.isAndroidEnvironment()) {
      return ''; // Return empty for non-Android
    }

    // Strict format: intent://#Intent;package=PACKAGE_NAME;end
    const intentUrl = `intent://#Intent;package=${packageName};end`;
    
    // Validate intent URL
    const validation = PlayStoreBan.validateIntentUrl(intentUrl);
    if (!validation.valid) {
      console.error(`[PLAY STORE BAN] Invalid intent URL: ${validation.error}`);
      return '';
    }

    return intentUrl;
  }

  // Generate WhatsApp message intent with strict format
  static generateWhatsAppIntent(message: string): string {
    if (!this.isAndroidEnvironment()) {
      return '';
    }

    // Corrected WhatsApp intent format
    const intentUrl = `intent://send?text=${encodeURIComponent(message)}#Intent;scheme=whatsapp;package=com.whatsapp;end`;
    
    // Validate intent URL
    const validation = PlayStoreBan.validateIntentUrl(intentUrl);
    if (!validation.valid) {
      console.error(`[PLAY STORE BAN] Invalid WhatsApp intent: ${validation.error}`);
      return '';
    }

    return intentUrl;
  }

  // Launch app with strict local-only approach and Play Store ban enforcement
  static async launchApp(packageName: string): Promise<{ success: boolean; error?: string }> {
    if (!this.isAndroidEnvironment()) {
      return { success: false, error: 'Not an Android device' };
    }

    const intentUrl = this.generateStrictIntent(packageName);
    if (!intentUrl) {
      return { success: false, error: 'Failed to generate intent URL' };
    }

    // Final validation before launch
    const validation = PlayStoreBan.validateIntentUrl(intentUrl);
    if (!validation.valid) {
      PlayStoreBan.blockRedirection(intentUrl, 'AndroidIntentLauncher.launchApp');
      return { success: false, error: 'This app is not installed on your device.' };
    }

    try {
      // Attempt to launch the app
      window.location.href = intentUrl;
      
      // Wait to check if app launched
      return new Promise((resolve) => {
        setTimeout(() => {
          // If still on page, app likely not installed
          if (document.hasFocus()) {
            resolve({ success: false, error: 'This app is not installed on your device.' });
          } else {
            resolve({ success: true });
          }
        }, 2000);
      });
    } catch (error) {
      return { success: false, error: 'This app is not installed on your device.' };
    }
  }

  // Get verified package mappings with hard-coded entries
  static getPackageMapping(): Map<string, { name: string; package: string }> {
    return new Map([
      // Social & Messaging
      ['whatsapp', { name: 'WhatsApp', package: 'com.whatsapp' }],
      ['telegram', { name: 'Telegram', package: 'org.telegram.messenger' }],
      ['instagram', { name: 'Instagram', package: 'com.instagram.android' }],
      ['facebook', { name: 'Facebook', package: 'com.facebook.katana' }],
      ['messenger', { name: 'Messenger', package: 'com.facebook.orca' }],
      ['twitter', { name: 'Twitter', package: 'com.twitter.android' }],
      ['x', { name: 'X', package: 'com.twitter.android' }],
      ['linkedin', { name: 'LinkedIn', package: 'com.linkedin.android' }],
      ['snapchat', { name: 'Snapchat', package: 'com.snapchat.android' }],
      ['tiktok', { name: 'TikTok', package: 'com.zhiliaoapp.musically' }],
      ['discord', { name: 'Discord', package: 'com.discord' }],
      ['reddit', { name: 'Reddit', package: 'com.reddit.frontpage' }],
      
      // Media & Entertainment
      ['youtube', { name: 'YouTube', package: 'com.google.android.youtube' }],
      ['spotify', { name: 'Spotify', package: 'com.spotify.music' }],
      ['music', { name: 'Spotify', package: 'com.spotify.music' }],
      ['netflix', { name: 'Netflix', package: 'com.netflix.mediaclient' }],
      ['hotstar', { name: 'Hotstar', package: 'in.startv.hotstar' }],
      ['prime', { name: 'Prime Video', package: 'com.amazon.avod.thirdpartyclient' }],
      
      // Productivity & Tools
      ['gmail', { name: 'Gmail', package: 'com.google.android.gm' }],
      ['chrome', { name: 'Chrome', package: 'com.android.chrome' }],
      ['maps', { name: 'Google Maps', package: 'com.google.android.apps.maps' }],
      ['drive', { name: 'Google Drive', package: 'com.google.android.apps.docs' }],
      ['photos', { name: 'Google Photos', package: 'com.google.android.apps.photos' }],
      ['calendar', { name: 'Google Calendar', package: 'com.google.android.calendar' }],
      ['keep', { name: 'Google Keep', package: 'com.google.android.keep' }],
      ['docs', { name: 'Google Docs', package: 'com.google.android.apps.docs.editors.docs' }],
      ['sheets', { name: 'Google Sheets', package: 'com.google.android.apps.docs.editors.sheets' }],
      ['slides', { name: 'Google Slides', package: 'com.google.android.apps.docs.editors.slides' }],
      
      // Shopping & Finance
      ['amazon', { name: 'Amazon', package: 'in.amazon.mShop.android.shopping' }],
      ['flipkart', { name: 'Flipkart', package: 'com.flipkart.android' }],
      ['paytm', { name: 'Paytm', package: 'net.one97.paytm' }],
      ['phonepe', { name: 'PhonePe', package: 'com.phonepe.app' }],
      ['gpay', { name: 'Google Pay', package: 'com.google.android.apps.nbu.paisa.user' }],
      ['swiggy', { name: 'Swiggy', package: 'in.swiggy.android' }],
      ['zomato', { name: 'Zomato', package: 'com.application.zomato' }],
      
      // System Apps
      ['settings', { name: 'Settings', package: 'com.android.settings' }],
      ['calculator', { name: 'Calculator', package: 'com.google.android.calculator' }],
      ['camera', { name: 'Camera', package: 'com.android.camera2' }],
      ['phone', { name: 'Phone', package: 'com.android.dialer' }],
      ['messages', { name: 'Messages', package: 'com.google.android.apps.messaging' }],
      ['contacts', { name: 'Contacts', package: 'com.android.contacts' }],
      ['clock', { name: 'Clock', package: 'com.google.android.deskclock' }],
      ['files', { name: 'Files', package: 'com.google.android.apps.nbu.files' }],
      ['termux', { name: 'Termux', package: 'com.termux' }],
      ['gallery', { name: 'Gallery', package: 'com.android.gallery3d' }],
      ['downloads', { name: 'Downloads', package: 'com.android.providers.downloads.ui' }],
    ]);
  }

  // Validate package name exists in mapping
  static isValidPackage(packageName: string): boolean {
    for (const [_, value] of this.getPackageMapping()) {
      if (value.package === packageName) {
        return true;
      }
    }
    return false;
  }

  // Get app name from package
  static getAppNameFromPackage(packageName: string): string | null {
    for (const [_, value] of this.getPackageMapping()) {
      if (value.package === packageName) {
        return value.name;
      }
    }
    return null;
  }
}
