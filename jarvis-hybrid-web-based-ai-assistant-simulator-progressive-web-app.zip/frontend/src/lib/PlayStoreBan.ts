// Runtime validation system preventing Play Store redirections with comprehensive logging
// Enforces permanent ban on market://, play.google.com, and web fallback logic

export class PlayStoreBan {
  private static blockedPatterns = [
    /market:\/\//i,
    /play\.google\.com/i,
    /play\.app\.goo\.gl/i,
    /android\.com\/store/i,
  ];

  private static blockedLog: Array<{ timestamp: number; url: string; source: string }> = [];

  // Check if URL contains Play Store redirection
  static isPlayStoreUrl(url: string): boolean {
    return this.blockedPatterns.some(pattern => pattern.test(url));
  }

  // Block and log Play Store redirection attempt
  static blockRedirection(url: string, source: string): void {
    const entry = {
      timestamp: Date.now(),
      url,
      source,
    };
    
    this.blockedLog.push(entry);
    console.warn(`[PLAY STORE BLOCKED] Attempted redirection from ${source}: ${url}`);
    
    // Dispatch event for UI notification
    window.dispatchEvent(new CustomEvent('play-store-blocked', { 
      detail: entry 
    }));
  }

  // Validate intent URL format
  static validateIntentUrl(url: string): { valid: boolean; error?: string } {
    if (!url) {
      return { valid: false, error: 'Empty URL' };
    }

    // Must start with intent://
    if (!url.startsWith('intent://')) {
      return { valid: false, error: 'Invalid intent URL format' };
    }

    // Must contain package parameter
    if (!url.includes('package=')) {
      return { valid: false, error: 'Missing package parameter' };
    }

    // Must end with ;end
    if (!url.endsWith(';end')) {
      return { valid: false, error: 'Invalid intent URL termination' };
    }

    // Check for Play Store patterns
    if (this.isPlayStoreUrl(url)) {
      return { valid: false, error: 'Play Store redirection detected' };
    }

    return { valid: true };
  }

  // Get blocked attempts log
  static getBlockedLog(): Array<{ timestamp: number; url: string; source: string }> {
    return [...this.blockedLog];
  }

  // Clear blocked log
  static clearLog(): void {
    this.blockedLog = [];
  }

  // Intercept window.location.href assignments
  static installInterceptor(): void {
    const originalLocationSetter = Object.getOwnPropertyDescriptor(window.Location.prototype, 'href')?.set;
    
    if (originalLocationSetter) {
      Object.defineProperty(window.Location.prototype, 'href', {
        set: function(url: string) {
          if (PlayStoreBan.isPlayStoreUrl(url)) {
            PlayStoreBan.blockRedirection(url, 'window.location.href');
            console.error('[PLAY STORE BLOCKED] Prevented Play Store redirection');
            return;
          }
          originalLocationSetter.call(this, url);
        },
        get: function() {
          return window.location.href;
        }
      });
    }

    // Intercept window.open
    const originalWindowOpen = window.open;
    window.open = function(url?: string | URL, target?: string, features?: string) {
      if (url && PlayStoreBan.isPlayStoreUrl(url.toString())) {
        PlayStoreBan.blockRedirection(url.toString(), 'window.open');
        console.error('[PLAY STORE BLOCKED] Prevented Play Store window.open');
        return null;
      }
      return originalWindowOpen.call(window, url, target, features);
    };

    console.log('[PLAY STORE BAN] Interceptor installed successfully');
  }
}

// Auto-install interceptor on module load
if (typeof window !== 'undefined') {
  PlayStoreBan.installInterceptor();
}
