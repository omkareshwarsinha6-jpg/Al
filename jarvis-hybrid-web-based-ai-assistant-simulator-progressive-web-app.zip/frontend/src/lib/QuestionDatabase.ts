// IndexedDB wrapper for PWA question-answer storage with 200 MB capacity
// Provides CRUD operations, search, categorization, favorites, and history tracking

export interface Question {
  id: string;
  question: string;
  answer: string;
  categories: string[];
  isFavorite: boolean;
  createdAt: number;
  updatedAt: number;
  accessCount: number;
  lastAccessed: number;
}

export interface QuestionHistory {
  questionId: string;
  accessedAt: number;
}

export interface Category {
  id: string;
  name: string;
  color: string;
  createdAt: number;
}

export class QuestionDatabase {
  private static DB_NAME = 'jarvis_pwa_questions';
  private static DB_VERSION = 1;
  private static QUESTIONS_STORE = 'questions';
  private static HISTORY_STORE = 'history';
  private static CATEGORIES_STORE = 'categories';
  private static db: IDBDatabase | null = null;

  // Initialize IndexedDB
  static async initialize(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Create questions store
        if (!db.objectStoreNames.contains(this.QUESTIONS_STORE)) {
          const questionsStore = db.createObjectStore(this.QUESTIONS_STORE, { keyPath: 'id' });
          questionsStore.createIndex('question', 'question', { unique: false });
          questionsStore.createIndex('categories', 'categories', { unique: false, multiEntry: true });
          questionsStore.createIndex('isFavorite', 'isFavorite', { unique: false });
          questionsStore.createIndex('lastAccessed', 'lastAccessed', { unique: false });
        }

        // Create history store
        if (!db.objectStoreNames.contains(this.HISTORY_STORE)) {
          const historyStore = db.createObjectStore(this.HISTORY_STORE, { autoIncrement: true });
          historyStore.createIndex('questionId', 'questionId', { unique: false });
          historyStore.createIndex('accessedAt', 'accessedAt', { unique: false });
        }

        // Create categories store
        if (!db.objectStoreNames.contains(this.CATEGORIES_STORE)) {
          db.createObjectStore(this.CATEGORIES_STORE, { keyPath: 'id' });
        }
      };
    });
  }

  // Add new question
  static async addQuestion(question: Omit<Question, 'id' | 'createdAt' | 'updatedAt' | 'accessCount' | 'lastAccessed'>): Promise<string> {
    if (!this.db) await this.initialize();

    const id = `q_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const newQuestion: Question = {
      ...question,
      id,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      accessCount: 0,
      lastAccessed: 0,
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.QUESTIONS_STORE], 'readwrite');
      const store = transaction.objectStore(this.QUESTIONS_STORE);
      const request = store.add(newQuestion);

      request.onsuccess = () => resolve(id);
      request.onerror = () => reject(request.error);
    });
  }

  // Get question by ID
  static async getQuestion(id: string): Promise<Question | null> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.QUESTIONS_STORE], 'readonly');
      const store = transaction.objectStore(this.QUESTIONS_STORE);
      const request = store.get(id);

      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  // Get all questions
  static async getAllQuestions(): Promise<Question[]> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.QUESTIONS_STORE], 'readonly');
      const store = transaction.objectStore(this.QUESTIONS_STORE);
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  // Update question
  static async updateQuestion(id: string, updates: Partial<Omit<Question, 'id' | 'createdAt'>>): Promise<void> {
    if (!this.db) await this.initialize();

    const existing = await this.getQuestion(id);
    if (!existing) throw new Error('Question not found');

    const updated: Question = {
      ...existing,
      ...updates,
      updatedAt: Date.now(),
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.QUESTIONS_STORE], 'readwrite');
      const store = transaction.objectStore(this.QUESTIONS_STORE);
      const request = store.put(updated);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // Delete question
  static async deleteQuestion(id: string): Promise<void> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.QUESTIONS_STORE], 'readwrite');
      const store = transaction.objectStore(this.QUESTIONS_STORE);
      const request = store.delete(id);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // Search questions (case-insensitive)
  static async searchQuestions(searchText: string): Promise<Question[]> {
    const allQuestions = await this.getAllQuestions();
    const lowerSearch = searchText.toLowerCase();

    return allQuestions.filter(q =>
      q.question.toLowerCase().includes(lowerSearch) ||
      q.answer.toLowerCase().includes(lowerSearch) ||
      q.categories.some(c => c.toLowerCase().includes(lowerSearch))
    );
  }

  // Get questions by category
  static async getQuestionsByCategory(category: string): Promise<Question[]> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.QUESTIONS_STORE], 'readonly');
      const store = transaction.objectStore(this.QUESTIONS_STORE);
      const index = store.index('categories');
      const request = index.getAll(category);

      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  // Get favorite questions
  static async getFavoriteQuestions(): Promise<Question[]> {
    if (!this.db) await this.initialize();

    // Get all questions and filter by isFavorite
    const allQuestions = await this.getAllQuestions();
    return allQuestions.filter(q => q.isFavorite === true);
  }

  // Toggle favorite status
  static async toggleFavorite(id: string): Promise<void> {
    const question = await this.getQuestion(id);
    if (!question) throw new Error('Question not found');

    await this.updateQuestion(id, { isFavorite: !question.isFavorite });
  }

  // Record question access
  static async recordAccess(id: string): Promise<void> {
    const question = await this.getQuestion(id);
    if (!question) return;

    // Update question access stats
    await this.updateQuestion(id, {
      accessCount: question.accessCount + 1,
      lastAccessed: Date.now(),
    });

    // Add to history
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.HISTORY_STORE], 'readwrite');
      const store = transaction.objectStore(this.HISTORY_STORE);
      const history: QuestionHistory = {
        questionId: id,
        accessedAt: Date.now(),
      };
      const request = store.add(history);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // Get recent history
  static async getRecentHistory(limit: number = 20): Promise<Question[]> {
    if (!this.db) await this.initialize();

    return new Promise(async (resolve, reject) => {
      const transaction = this.db!.transaction([this.HISTORY_STORE], 'readonly');
      const store = transaction.objectStore(this.HISTORY_STORE);
      const index = store.index('accessedAt');
      const request = index.openCursor(null, 'prev');

      const questionIds: string[] = [];
      const seenIds = new Set<string>();

      request.onsuccess = async (event) => {
        const cursor = (event.target as IDBRequest).result;
        if (cursor && questionIds.length < limit) {
          const history = cursor.value as QuestionHistory;
          if (!seenIds.has(history.questionId)) {
            questionIds.push(history.questionId);
            seenIds.add(history.questionId);
          }
          cursor.continue();
        } else {
          // Fetch questions
          const questions = await Promise.all(
            questionIds.map(id => this.getQuestion(id))
          );
          resolve(questions.filter(q => q !== null) as Question[]);
        }
      };

      request.onerror = () => reject(request.error);
    });
  }

  // Get random question
  static async getRandomQuestion(): Promise<Question | null> {
    const allQuestions = await this.getAllQuestions();
    if (allQuestions.length === 0) return null;

    const randomIndex = Math.floor(Math.random() * allQuestions.length);
    return allQuestions[randomIndex];
  }

  // Category management
  static async addCategory(name: string, color: string): Promise<string> {
    if (!this.db) await this.initialize();

    const id = `cat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const category: Category = {
      id,
      name,
      color,
      createdAt: Date.now(),
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.CATEGORIES_STORE], 'readwrite');
      const store = transaction.objectStore(this.CATEGORIES_STORE);
      const request = store.add(category);

      request.onsuccess = () => resolve(id);
      request.onerror = () => reject(request.error);
    });
  }

  static async getAllCategories(): Promise<Category[]> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.CATEGORIES_STORE], 'readonly');
      const store = transaction.objectStore(this.CATEGORIES_STORE);
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  static async deleteCategory(id: string): Promise<void> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.CATEGORIES_STORE], 'readwrite');
      const store = transaction.objectStore(this.CATEGORIES_STORE);
      const request = store.delete(id);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // Export all data
  static async exportData(): Promise<{ questions: Question[]; categories: Category[] }> {
    const questions = await this.getAllQuestions();
    const categories = await this.getAllCategories();
    return { questions, categories };
  }

  // Import data
  static async importData(data: { questions: Question[]; categories?: Category[] }): Promise<void> {
    if (!this.db) await this.initialize();

    // Import categories first
    if (data.categories) {
      for (const category of data.categories) {
        try {
          const transaction = this.db!.transaction([this.CATEGORIES_STORE], 'readwrite');
          const store = transaction.objectStore(this.CATEGORIES_STORE);
          await new Promise((resolve, reject) => {
            const request = store.put(category);
            request.onsuccess = () => resolve(undefined);
            request.onerror = () => reject(request.error);
          });
        } catch (error) {
          console.error('Error importing category:', error);
        }
      }
    }

    // Import questions
    for (const question of data.questions) {
      try {
        const transaction = this.db!.transaction([this.QUESTIONS_STORE], 'readwrite');
        const store = transaction.objectStore(this.QUESTIONS_STORE);
        await new Promise((resolve, reject) => {
          const request = store.put(question);
          request.onsuccess = () => resolve(undefined);
          request.onerror = () => reject(request.error);
        });
      } catch (error) {
        console.error('Error importing question:', error);
      }
    }
  }

  // Clear all data
  static async clearAllData(): Promise<void> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(
        [this.QUESTIONS_STORE, this.HISTORY_STORE, this.CATEGORIES_STORE],
        'readwrite'
      );

      transaction.objectStore(this.QUESTIONS_STORE).clear();
      transaction.objectStore(this.HISTORY_STORE).clear();
      transaction.objectStore(this.CATEGORIES_STORE).clear();

      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }

  // Get storage usage estimate
  static async getStorageUsage(): Promise<{ used: number; quota: number; percentage: number }> {
    if ('storage' in navigator && 'estimate' in navigator.storage) {
      const estimate = await navigator.storage.estimate();
      const used = estimate.usage || 0;
      const quota = estimate.quota || 200 * 1024 * 1024; // Default 200 MB
      const percentage = (used / quota) * 100;
      return { used, quota, percentage };
    }
    return { used: 0, quota: 200 * 1024 * 1024, percentage: 0 };
  }
}
