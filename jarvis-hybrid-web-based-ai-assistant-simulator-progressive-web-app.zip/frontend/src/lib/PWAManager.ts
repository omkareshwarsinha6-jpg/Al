// PWA Manager for service worker registration and PWA features
// Handles offline functionality, caching, and background sync

export class PWAManager {
  private static serviceWorkerRegistration: ServiceWorkerRegistration | null = null;

  // Check if PWA features are supported
  static isSupported(): boolean {
    return 'serviceWorker' in navigator && 'PushManager' in window;
  }

  // Initialize PWA features
  static async initialize(): Promise<void> {
    if (!this.isSupported()) {
      console.warn('PWA features not supported in this browser');
      return;
    }

    try {
      // Register service worker
      const registration = await navigator.serviceWorker.register('/sw.js', {
        scope: '/',
      });

      this.serviceWorkerRegistration = registration;
      console.log('Service Worker registered:', registration);

      // Listen for updates
      registration.addEventListener('updatefound', () => {
        const newWorker = registration.installing;
        if (newWorker) {
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              console.log('New service worker available');
              // Optionally notify user about update
            }
          });
        }
      });
    } catch (error) {
      console.error('Service Worker registration failed:', error);
    }
  }

  // Get service worker registration
  static getRegistration(): ServiceWorkerRegistration | null {
    return this.serviceWorkerRegistration;
  }

  // Check if app is installed as PWA
  static isInstalled(): boolean {
    return window.matchMedia('(display-mode: standalone)').matches ||
           (window.navigator as any).standalone === true;
  }

  // Get installation prompt
  static async getInstallPrompt(): Promise<any> {
    return new Promise((resolve) => {
      window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        resolve(e);
      });
    });
  }
}
