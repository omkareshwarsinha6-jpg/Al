// Enhanced Google search processor with top results fetching and caching
// Provides intelligent search with offline fallback support

export interface SearchResult {
  title: string;
  snippet: string;
  url: string;
}

export interface SearchResponse {
  query: string;
  results: SearchResult[];
  timestamp: number;
}

export class SearchProcessor {
  private static CACHE_KEY = 'jarvis_search_cache';
  private static CACHE_EXPIRY = 60 * 60 * 1000; // 1 hour

  // Get cached search results
  private static getCachedResults(query: string): SearchResponse | null {
    try {
      const cached = localStorage.getItem(`${this.CACHE_KEY}_${query.toLowerCase()}`);
      if (!cached) return null;

      const parsed: SearchResponse = JSON.parse(cached);
      const now = Date.now();

      if (now - parsed.timestamp < this.CACHE_EXPIRY) {
        return parsed;
      }

      // Remove expired cache
      localStorage.removeItem(`${this.CACHE_KEY}_${query.toLowerCase()}`);
      return null;
    } catch (error) {
      console.error('Error getting cached results:', error);
      return null;
    }
  }

  // Cache search results
  private static cacheResults(query: string, results: SearchResult[]): void {
    try {
      const response: SearchResponse = {
        query,
        results,
        timestamp: Date.now(),
      };
      localStorage.setItem(`${this.CACHE_KEY}_${query.toLowerCase()}`, JSON.stringify(response));
    } catch (error) {
      console.error('Error caching results:', error);
    }
  }

  // Fetch top Google search results
  static async searchGoogle(query: string): Promise<SearchResponse> {
    // Check cache first
    const cached = this.getCachedResults(query);
    if (cached) {
      return cached;
    }

    try {
      // Try Wikipedia first for factual queries
      const wikiResponse = await fetch(
        `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`
      );

      if (wikiResponse.ok) {
        const wikiData = await wikiResponse.json();
        const results: SearchResult[] = [];

        if (wikiData.extract) {
          results.push({
            title: wikiData.title,
            snippet: wikiData.extract.substring(0, 200) + '...',
            url: wikiData.content_urls?.desktop?.page || `https://en.wikipedia.org/wiki/${encodeURIComponent(query.replace(/ /g, '_'))}`,
          });
        }

        // Add Google search link
        results.push({
          title: `${query} - Google Search`,
          snippet: 'Search Google for more results',
          url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
        });

        // Add related searches
        results.push({
          title: `${query} - Images`,
          snippet: 'View images related to your search',
          url: `https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=isch`,
        });

        results.push({
          title: `${query} - News`,
          snippet: 'Latest news about your search',
          url: `https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=nws`,
        });

        const response: SearchResponse = {
          query,
          results,
          timestamp: Date.now(),
        };

        this.cacheResults(query, results);
        return response;
      }
    } catch (error) {
      console.error('Search error:', error);
    }

    // Fallback to basic Google links
    const fallbackResults: SearchResult[] = [
      {
        title: `${query} - Google Search`,
        snippet: 'Search Google for results',
        url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
      },
      {
        title: `${query} - Wikipedia`,
        snippet: 'Search Wikipedia for information',
        url: `https://en.wikipedia.org/wiki/${encodeURIComponent(query.replace(/ /g, '_'))}`,
      },
      {
        title: `${query} - Images`,
        snippet: 'View images',
        url: `https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=isch`,
      },
      {
        title: `${query} - News`,
        snippet: 'Latest news',
        url: `https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=nws`,
      },
    ];

    const response: SearchResponse = {
      query,
      results: fallbackResults,
      timestamp: Date.now(),
    };

    this.cacheResults(query, fallbackResults);
    return response;
  }

  // Get offline fallback results
  static getOfflineFallback(query: string): SearchResponse {
    const cached = this.getCachedResults(query);
    if (cached) {
      return cached;
    }

    return {
      query,
      results: [
        {
          title: 'Offline Mode',
          snippet: 'Search results are not available offline. Connect to the internet to search.',
          url: '',
        },
      ],
      timestamp: Date.now(),
    };
  }

  // Clear search cache
  static clearCache(): void {
    try {
      const keys = Object.keys(localStorage);
      keys.forEach(key => {
        if (key.startsWith(this.CACHE_KEY)) {
          localStorage.removeItem(key);
        }
      });
    } catch (error) {
      console.error('Error clearing cache:', error);
    }
  }
}
