// Enhanced system state detector with safe initialization and error handling
// Provides real-time monitoring of connectivity, microphone, and viewport
// Includes responsive Android screen adjustments and proper mobile scaling

export interface SystemState {
  isOnline: boolean;
  hasMicrophoneAccess: boolean;
  hasNotificationPermission: boolean;
  batteryLevel?: number;
  isLowPowerMode?: boolean;
  viewportWidth: number;
  viewportHeight: number;
  isPortrait: boolean;
}

export class SystemStateDetector {
  private static listeners: Array<(state: SystemState) => void> = [];
  private static currentState: SystemState = {
    isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
    hasMicrophoneAccess: false,
    hasNotificationPermission: false,
    viewportWidth: typeof window !== 'undefined' ? window.innerWidth : 1024,
    viewportHeight: typeof window !== 'undefined' ? window.innerHeight : 768,
    isPortrait: typeof window !== 'undefined' ? window.innerHeight > window.innerWidth : false,
  };
  private static isInitialized = false;

  // Initialize system state monitoring with safe error handling
  static initialize(): void {
    // Prevent multiple initializations
    if (this.isInitialized) {
      return;
    }

    try {
      // Ensure we're in a browser environment
      if (typeof window === 'undefined') {
        return;
      }

      // Monitor online/offline status
      window.addEventListener('online', () => {
        this.updateState({ isOnline: true });
        this.notifyListeners('Connection restored. Online features available.');
      });

      window.addEventListener('offline', () => {
        this.updateState({ isOnline: false });
        this.notifyListeners('Connection lost. Switching to offline mode.');
      });

      // Monitor viewport changes for responsive Android adjustments
      const handleResize = () => {
        try {
          this.updateState({
            viewportWidth: window.innerWidth,
            viewportHeight: window.innerHeight,
            isPortrait: window.innerHeight > window.innerWidth,
          });
        } catch (error) {
          console.error('Error handling resize:', error);
        }
      };

      window.addEventListener('resize', handleResize);

      // Monitor orientation changes
      window.addEventListener('orientationchange', () => {
        setTimeout(() => {
          try {
            this.updateState({
              viewportWidth: window.innerWidth,
              viewportHeight: window.innerHeight,
              isPortrait: window.innerHeight > window.innerWidth,
            });
          } catch (error) {
            console.error('Error handling orientation change:', error);
          }
        }, 100);
      });

      // Check microphone access
      this.checkMicrophoneAccess().catch(error => {
        console.error('Error checking microphone access:', error);
      });

      // Check notification permission
      if ('Notification' in window) {
        this.currentState.hasNotificationPermission = Notification.permission === 'granted';
      }

      // Monitor battery status if available
      if ('getBattery' in navigator) {
        (navigator as any).getBattery().then((battery: any) => {
          this.updateState({
            batteryLevel: battery.level * 100,
            isLowPowerMode: battery.level < 0.2,
          });

          battery.addEventListener('levelchange', () => {
            this.updateState({
              batteryLevel: battery.level * 100,
              isLowPowerMode: battery.level < 0.2,
            });

            if (battery.level < 0.2) {
              this.notifyListeners('Battery low. Consider enabling performance mode.');
            }
          });
        }).catch((error: any) => {
          console.error('Error accessing battery API:', error);
        });
      }

      // Apply responsive viewport meta tag for Android
      this.applyResponsiveViewport();

      this.isInitialized = true;
    } catch (error) {
      console.error('SystemStateDetector initialization error:', error);
    }
  }

  // Apply responsive viewport settings for Android with safe DOM manipulation
  static applyResponsiveViewport(): void {
    try {
      if (typeof document === 'undefined') {
        return;
      }

      let viewport = document.querySelector('meta[name="viewport"]');
      
      if (!viewport) {
        viewport = document.createElement('meta');
        viewport.setAttribute('name', 'viewport');
        document.head.appendChild(viewport);
      }
      
      // Set viewport for proper mobile scaling
      viewport.setAttribute(
        'content',
        'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover'
      );
    } catch (error) {
      console.error('Error applying responsive viewport:', error);
    }
  }

  // Check microphone access with safe error handling
  static async checkMicrophoneAccess(): Promise<boolean> {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        return false;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(track => track.stop());
      this.updateState({ hasMicrophoneAccess: true });
      return true;
    } catch (error) {
      this.updateState({ hasMicrophoneAccess: false });
      return false;
    }
  }

  // Request microphone permission with safe error handling
  static async requestMicrophonePermission(): Promise<boolean> {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        this.notifyListeners('Microphone not available on this device.');
        return false;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(track => track.stop());
      this.updateState({ hasMicrophoneAccess: true });
      this.notifyListeners('Microphone access granted.');
      return true;
    } catch (error) {
      this.updateState({ hasMicrophoneAccess: false });
      this.notifyListeners('Microphone access denied. Please enable in settings.');
      return false;
    }
  }

  // Request notification permission with safe error handling
  static async requestNotificationPermission(): Promise<boolean> {
    try {
      if (!('Notification' in window)) {
        return false;
      }

      const permission = await Notification.requestPermission();
      const granted = permission === 'granted';
      this.updateState({ hasNotificationPermission: granted });
      return granted;
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      return false;
    }
  }

  // Update state safely
  private static updateState(updates: Partial<SystemState>): void {
    try {
      this.currentState = { ...this.currentState, ...updates };
    } catch (error) {
      console.error('Error updating system state:', error);
    }
  }

  // Get current state with safe fallback
  static getState(): SystemState {
    return { ...this.currentState };
  }

  // Add state change listener
  static addListener(callback: (state: SystemState) => void): void {
    if (typeof callback === 'function') {
      this.listeners.push(callback);
    }
  }

  // Remove state change listener
  static removeListener(callback: (state: SystemState) => void): void {
    this.listeners = this.listeners.filter(l => l !== callback);
  }

  // Notify listeners with message and safe error handling
  private static notifyListeners(message: string): void {
    try {
      this.listeners.forEach(listener => {
        try {
          listener(this.currentState);
        } catch (error) {
          console.error('Error in state listener:', error);
        }
      });
      
      // Trigger custom event for voice feedback
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('system-state-change', {
          detail: { state: this.currentState, message }
        }));
      }
    } catch (error) {
      console.error('Error notifying listeners:', error);
    }
  }

  // Check if running in WebView (APK)
  static isWebView(): boolean {
    try {
      if (typeof navigator === 'undefined') {
        return false;
      }
      const userAgent = navigator.userAgent.toLowerCase();
      return userAgent.includes('wv') || 
             userAgent.includes('webview') ||
             (window as any).Android !== undefined;
    } catch (error) {
      return false;
    }
  }

  // Check if running on Android
  static isAndroid(): boolean {
    try {
      if (typeof navigator === 'undefined') {
        return false;
      }
      return /android/i.test(navigator.userAgent);
    } catch (error) {
      return false;
    }
  }

  // Get device info with safe fallbacks
  static getDeviceInfo(): { 
    platform: string; 
    isWebView: boolean; 
    isAndroid: boolean; 
    viewport: { width: number; height: number; isPortrait: boolean } 
  } {
    return {
      platform: typeof navigator !== 'undefined' ? navigator.platform : 'unknown',
      isWebView: this.isWebView(),
      isAndroid: this.isAndroid(),
      viewport: {
        width: this.currentState.viewportWidth,
        height: this.currentState.viewportHeight,
        isPortrait: this.currentState.isPortrait,
      },
    };
  }

  // Get responsive CSS class for Android adjustments
  static getResponsiveClass(): string {
    const isAndroid = this.isAndroid();
    const isWebView = this.isWebView();
    const isPortrait = this.currentState.isPortrait;
    
    if (isAndroid && isWebView) {
      return isPortrait ? 'android-webview-portrait' : 'android-webview-landscape';
    } else if (isAndroid) {
      return isPortrait ? 'android-portrait' : 'android-landscape';
    }
    
    return '';
  }
}
