// Enhanced offline command processing engine with native Android app launching
// Provides direct app opening via intent URLs with package name resolution
// No Play Store redirections - only opens locally installed apps

export interface CommandResult {
  handled: boolean;
  response: string;
  action?: {
    type: string;
    target?: string;
    intentUrl?: string;
    webFallbackUrl?: string;
  };
}

// Intent URL generator for direct Android app launching
export class IntentEngine {
  // Detect if running in Android environment
  static isAndroidEnvironment(): boolean {
    const userAgent = navigator.userAgent.toLowerCase();
    return /android/i.test(userAgent);
  }

  // Detect if running in WebView (APK)
  static isWebView(): boolean {
    const userAgent = navigator.userAgent.toLowerCase();
    return userAgent.includes('wv') || 
           userAgent.includes('webview') ||
           (window as any).Android !== undefined;
  }

  // Generate direct Android app intent URL (no Play Store fallback)
  static generateDirectAppIntent(packageName: string): string {
    const isAndroid = this.isAndroidEnvironment();
    
    if (!isAndroid) {
      return ''; // Return empty for non-Android
    }

    // Direct app launch intent without Play Store fallback
    return `intent://${packageName}#Intent;scheme=android-app;end`;
  }

  // Generate WhatsApp message intent
  static generateWhatsAppMessageIntent(phoneNumber?: string, message?: string): string {
    const isAndroid = this.isAndroidEnvironment();
    
    if (!isAndroid) {
      return 'https://web.whatsapp.com';
    }

    return this.generateDirectAppIntent('com.whatsapp');
  }

  // Generate YouTube search intent
  static generateYouTubeSearchIntent(query: string): string {
    const isAndroid = this.isAndroidEnvironment();
    
    if (!isAndroid) {
      return `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
    }

    return this.generateDirectAppIntent('com.google.android.youtube');
  }

  // Generate Maps navigation intent
  static generateMapsIntent(location: string): string {
    const isAndroid = this.isAndroidEnvironment();
    
    if (!isAndroid) {
      return `https://www.google.com/maps/search/${encodeURIComponent(location)}`;
    }

    return this.generateDirectAppIntent('com.google.android.apps.maps');
  }

  // Generate Gmail compose intent
  static generateGmailIntent(to?: string, subject?: string): string {
    const isAndroid = this.isAndroidEnvironment();
    
    if (!isAndroid) {
      return 'https://mail.google.com';
    }

    return this.generateDirectAppIntent('com.google.android.gm');
  }

  // Generate app-specific intent with web fallback
  static generateAppIntent(packageName: string, webUrl: string): { intentUrl: string; webFallbackUrl: string } {
    const isAndroid = this.isAndroidEnvironment();
    
    return {
      intentUrl: isAndroid ? this.generateDirectAppIntent(packageName) : '',
      webFallbackUrl: webUrl
    };
  }
}

export class OfflineCommandEngine {
  private commandAliases: Map<string, string[]>;
  private appMappings: Map<string, { name: string; package: string; webUrl: string }>;

  constructor() {
    // Initialize command aliases for flexible matching
    this.commandAliases = new Map([
      ['open', ['launch', 'start', 'run', 'show']],
      ['search', ['find', 'look for', 'google', 'lookup']],
      ['close', ['exit', 'quit', 'stop']],
      ['help', ['assist', 'support']],
      ['send', ['message', 'text', 'whatsapp']],
    ]);

    // Initialize 60+ app mappings with package names and web URLs
    this.appMappings = new Map([
      // Social & Messaging (15 apps)
      ['whatsapp', { name: 'WhatsApp', package: 'com.whatsapp', webUrl: 'https://web.whatsapp.com' }],
      ['telegram', { name: 'Telegram', package: 'org.telegram.messenger', webUrl: 'https://web.telegram.org' }],
      ['instagram', { name: 'Instagram', package: 'com.instagram.android', webUrl: 'https://www.instagram.com' }],
      ['facebook', { name: 'Facebook', package: 'com.facebook.katana', webUrl: 'https://www.facebook.com' }],
      ['messenger', { name: 'Messenger', package: 'com.facebook.orca', webUrl: 'https://www.messenger.com' }],
      ['twitter', { name: 'Twitter', package: 'com.twitter.android', webUrl: 'https://twitter.com' }],
      ['x', { name: 'X (Twitter)', package: 'com.twitter.android', webUrl: 'https://twitter.com' }],
      ['linkedin', { name: 'LinkedIn', package: 'com.linkedin.android', webUrl: 'https://www.linkedin.com' }],
      ['snapchat', { name: 'Snapchat', package: 'com.snapchat.android', webUrl: 'https://www.snapchat.com' }],
      ['tiktok', { name: 'TikTok', package: 'com.zhiliaoapp.musically', webUrl: 'https://www.tiktok.com' }],
      ['discord', { name: 'Discord', package: 'com.discord', webUrl: 'https://discord.com' }],
      ['reddit', { name: 'Reddit', package: 'com.reddit.frontpage', webUrl: 'https://www.reddit.com' }],
      ['pinterest', { name: 'Pinterest', package: 'com.pinterest', webUrl: 'https://www.pinterest.com' }],
      ['skype', { name: 'Skype', package: 'com.skype.raider', webUrl: 'https://www.skype.com' }],
      ['viber', { name: 'Viber', package: 'com.viber.voip', webUrl: 'https://www.viber.com' }],
      
      // Media & Entertainment (15 apps)
      ['youtube', { name: 'YouTube', package: 'com.google.android.youtube', webUrl: 'https://www.youtube.com' }],
      ['spotify', { name: 'Spotify', package: 'com.spotify.music', webUrl: 'https://open.spotify.com' }],
      ['music', { name: 'Spotify', package: 'com.spotify.music', webUrl: 'https://open.spotify.com' }],
      ['netflix', { name: 'Netflix', package: 'com.netflix.mediaclient', webUrl: 'https://www.netflix.com' }],
      ['prime video', { name: 'Prime Video', package: 'com.amazon.avod.thirdpartyclient', webUrl: 'https://www.primevideo.com' }],
      ['hotstar', { name: 'Hotstar', package: 'in.startv.hotstar', webUrl: 'https://www.hotstar.com' }],
      ['zee5', { name: 'ZEE5', package: 'com.graymatrix.did', webUrl: 'https://www.zee5.com' }],
      ['sonyliv', { name: 'SonyLIV', package: 'com.sonyliv', webUrl: 'https://www.sonyliv.com' }],
      ['youtube music', { name: 'YouTube Music', package: 'com.google.android.apps.youtube.music', webUrl: 'https://music.youtube.com' }],
      ['gaana', { name: 'Gaana', package: 'com.gaana', webUrl: 'https://gaana.com' }],
      ['wynk', { name: 'Wynk Music', package: 'com.bsbportal.music', webUrl: 'https://wynk.in' }],
      ['jiosaavn', { name: 'JioSaavn', package: 'com.jio.media.jiobeats', webUrl: 'https://www.jiosaavn.com' }],
      ['mx player', { name: 'MX Player', package: 'com.mxtech.videoplayer.ad', webUrl: 'https://www.mxplayer.in' }],
      ['vlc', { name: 'VLC', package: 'org.videolan.vlc', webUrl: 'https://www.videolan.org' }],
      ['twitch', { name: 'Twitch', package: 'tv.twitch.android.app', webUrl: 'https://www.twitch.tv' }],
      ['soundcloud', { name: 'SoundCloud', package: 'com.soundcloud.android', webUrl: 'https://soundcloud.com' }],
      
      // Productivity & Tools (15 apps)
      ['gmail', { name: 'Gmail', package: 'com.google.android.gm', webUrl: 'https://mail.google.com' }],
      ['chrome', { name: 'Chrome', package: 'com.android.chrome', webUrl: 'https://www.google.com/chrome' }],
      ['maps', { name: 'Google Maps', package: 'com.google.android.apps.maps', webUrl: 'https://www.google.com/maps' }],
      ['drive', { name: 'Google Drive', package: 'com.google.android.apps.docs', webUrl: 'https://drive.google.com' }],
      ['photos', { name: 'Google Photos', package: 'com.google.android.apps.photos', webUrl: 'https://photos.google.com' }],
      ['calendar', { name: 'Google Calendar', package: 'com.google.android.calendar', webUrl: 'https://calendar.google.com' }],
      ['keep', { name: 'Google Keep', package: 'com.google.android.keep', webUrl: 'https://keep.google.com' }],
      ['docs', { name: 'Google Docs', package: 'com.google.android.apps.docs.editors.docs', webUrl: 'https://docs.google.com' }],
      ['sheets', { name: 'Google Sheets', package: 'com.google.android.apps.docs.editors.sheets', webUrl: 'https://sheets.google.com' }],
      ['slides', { name: 'Google Slides', package: 'com.google.android.apps.docs.editors.slides', webUrl: 'https://slides.google.com' }],
      ['outlook', { name: 'Outlook', package: 'com.microsoft.office.outlook', webUrl: 'https://outlook.com' }],
      ['onedrive', { name: 'OneDrive', package: 'com.microsoft.skydrive', webUrl: 'https://onedrive.live.com' }],
      ['dropbox', { name: 'Dropbox', package: 'com.dropbox.android', webUrl: 'https://www.dropbox.com' }],
      ['evernote', { name: 'Evernote', package: 'com.evernote', webUrl: 'https://www.evernote.com' }],
      ['notion', { name: 'Notion', package: 'notion.id', webUrl: 'https://www.notion.so' }],
      
      // Shopping & Finance (10 apps)
      ['amazon', { name: 'Amazon', package: 'in.amazon.mShop.android.shopping', webUrl: 'https://www.amazon.com' }],
      ['flipkart', { name: 'Flipkart', package: 'com.flipkart.android', webUrl: 'https://www.flipkart.com' }],
      ['myntra', { name: 'Myntra', package: 'com.myntra.android', webUrl: 'https://www.myntra.com' }],
      ['paytm', { name: 'Paytm', package: 'net.one97.paytm', webUrl: 'https://paytm.com' }],
      ['phonepe', { name: 'PhonePe', package: 'com.phonepe.app', webUrl: 'https://www.phonepe.com' }],
      ['gpay', { name: 'Google Pay', package: 'com.google.android.apps.nbu.paisa.user', webUrl: 'https://pay.google.com' }],
      ['paypal', { name: 'PayPal', package: 'com.paypal.android.p2pmobile', webUrl: 'https://www.paypal.com' }],
      ['swiggy', { name: 'Swiggy', package: 'in.swiggy.android', webUrl: 'https://www.swiggy.com' }],
      ['zomato', { name: 'Zomato', package: 'com.application.zomato', webUrl: 'https://www.zomato.com' }],
      ['uber', { name: 'Uber', package: 'com.ubercab', webUrl: 'https://www.uber.com' }],
      
      // System & Others (10 apps)
      ['ola', { name: 'Ola', package: 'com.olacabs.customer', webUrl: 'https://www.olacabs.com' }],
      ['truecaller', { name: 'Truecaller', package: 'com.truecaller', webUrl: 'https://www.truecaller.com' }],
      ['settings', { name: 'Settings', package: 'com.android.settings', webUrl: '' }],
      ['calculator', { name: 'Calculator', package: 'com.google.android.calculator', webUrl: '' }],
      ['camera', { name: 'Camera', package: 'com.android.camera2', webUrl: '' }],
      ['phone', { name: 'Phone', package: 'com.android.dialer', webUrl: '' }],
      ['messages', { name: 'Messages', package: 'com.google.android.apps.messaging', webUrl: '' }],
      ['contacts', { name: 'Contacts', package: 'com.android.contacts', webUrl: '' }],
      ['clock', { name: 'Clock', package: 'com.google.android.deskclock', webUrl: '' }],
      ['files', { name: 'Files', package: 'com.google.android.apps.nbu.files', webUrl: '' }],
    ]);
  }

  // Normalize command text for consistent matching
  private normalizeCommand(command: string): string {
    return command.toLowerCase().trim().replace(/[^\w\s]/g, '');
  }

  // Check if command matches any alias
  private matchesAlias(word: string, baseWord: string): boolean {
    if (word === baseWord) return true;
    const aliases = this.commandAliases.get(baseWord);
    return aliases ? aliases.includes(word) : false;
  }

  // Extract app name from command
  private extractAppName(normalized: string): string | null {
    for (const [key] of this.appMappings) {
      if (normalized.includes(key)) {
        return key;
      }
    }
    return null;
  }

  // Process command and return result
  processCommand(command: string): CommandResult {
    const normalized = this.normalizeCommand(command);
    const words = normalized.split(' ');

    // Handle "send message to [name]" pattern for WhatsApp
    if (normalized.match(/send.*message|message.*to|whatsapp.*to/)) {
      const intentUrl = IntentEngine.generateWhatsAppMessageIntent();
      const webFallbackUrl = 'https://web.whatsapp.com';
      
      return {
        handled: true,
        response: 'Opening WhatsApp',
        action: {
          type: 'intent',
          target: 'whatsapp',
          intentUrl: intentUrl || webFallbackUrl,
          webFallbackUrl,
        },
      };
    }

    // Handle app opening commands
    if (words.some(w => this.matchesAlias(w, 'open'))) {
      const appKey = this.extractAppName(normalized);
      if (appKey) {
        const app = this.appMappings.get(appKey);
        if (app) {
          const { intentUrl, webFallbackUrl } = IntentEngine.generateAppIntent(app.package, app.webUrl);
          
          return {
            handled: true,
            response: `Opening ${app.name}`,
            action: {
              type: 'intent',
              target: appKey,
              intentUrl: intentUrl || webFallbackUrl,
              webFallbackUrl,
            },
          };
        }
      }
    }

    // Handle YouTube search
    if (normalized.includes('youtube') && normalized.includes('search')) {
      const match = normalized.match(/youtube.*search\s+(.+)|search\s+(.+)\s+youtube/);
      if (match) {
        const query = match[1] || match[2];
        const intentUrl = IntentEngine.generateYouTubeSearchIntent(query);
        const webFallbackUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
        
        return {
          handled: true,
          response: `Opening YouTube`,
          action: {
            type: 'intent',
            target: 'youtube',
            intentUrl: intentUrl || webFallbackUrl,
            webFallbackUrl,
          },
        };
      }
    }

    // Handle Maps navigation
    if (normalized.includes('navigate') || normalized.includes('directions')) {
      const match = normalized.match(/(?:navigate|directions)\s+to\s+(.+)/);
      if (match) {
        const location = match[1];
        const intentUrl = IntentEngine.generateMapsIntent(location);
        const webFallbackUrl = `https://www.google.com/maps/search/${encodeURIComponent(location)}`;
        
        return {
          handled: true,
          response: `Opening Maps`,
          action: {
            type: 'intent',
            target: 'maps',
            intentUrl: intentUrl || webFallbackUrl,
            webFallbackUrl,
          },
        };
      }
    }

    // Handle time queries
    if (normalized.includes('time') || normalized.includes('clock')) {
      const time = new Date().toLocaleTimeString('en-IN', { 
        hour: '2-digit', 
        minute: '2-digit' 
      });
      return {
        handled: true,
        response: `The current time is ${time}`,
      };
    }

    // Handle date queries
    if (normalized.includes('date') || normalized.includes('today')) {
      const date = new Date().toLocaleDateString('en-IN', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
      return {
        handled: true,
        response: `Today is ${date}`,
      };
    }

    // Handle system actions
    if (normalized.includes('wifi') || normalized.includes('wi-fi')) {
      const intentUrl = IntentEngine.generateDirectAppIntent('com.android.settings');
      return {
        handled: true,
        response: 'Opening WiFi settings',
        action: {
          type: 'intent',
          target: 'wifi',
          intentUrl: intentUrl || '',
          webFallbackUrl: '',
        },
      };
    }

    if (normalized.includes('bluetooth')) {
      const intentUrl = IntentEngine.generateDirectAppIntent('com.android.settings');
      return {
        handled: true,
        response: 'Opening Bluetooth settings',
        action: {
          type: 'intent',
          target: 'bluetooth',
          intentUrl: intentUrl || '',
          webFallbackUrl: '',
        },
      };
    }

    // Handle help commands
    if (words.some(w => this.matchesAlias(w, 'help'))) {
      return {
        handled: true,
        response: 'I can help you with: opening 60+ apps, checking time/date, system settings, sending messages, and custom automations. Try saying "open YouTube" or "send message on WhatsApp".',
      };
    }

    // Command not handled by offline engine
    return {
      handled: false,
      response: '',
    };
  }

  // Add custom command alias
  addAlias(baseWord: string, alias: string) {
    const existing = this.commandAliases.get(baseWord) || [];
    this.commandAliases.set(baseWord, [...existing, alias]);
  }

  // Add custom app mapping
  addAppMapping(key: string, name: string, packageName: string, webUrl: string) {
    this.appMappings.set(key.toLowerCase(), { name, package: packageName, webUrl });
  }

  // Get all app mappings for UI display
  getAllApps(): Array<{ key: string; name: string; package: string; webUrl: string }> {
    return Array.from(this.appMappings.entries()).map(([key, value]) => ({
      key,
      ...value,
    }));
  }

  // Get top 20 most common apps
  getTopApps(): Array<{ key: string; name: string; package: string; webUrl: string }> {
    const topKeys = [
      'whatsapp', 'youtube', 'instagram', 'facebook', 'gmail',
      'chrome', 'maps', 'spotify', 'netflix', 'amazon',
      'telegram', 'twitter', 'linkedin', 'drive', 'photos',
      'paytm', 'phonepe', 'swiggy', 'zomato', 'uber'
    ];
    
    return topKeys
      .map(key => {
        const app = this.appMappings.get(key);
        return app ? { key, ...app } : null;
      })
      .filter(Boolean) as Array<{ key: string; name: string; package: string; webUrl: string }>;
  }
}
