// PWA-compliant reminder & notification system with IndexedDB storage and Browser Notifications API
// Supports natural language parsing for various time formats with Service Worker monitoring

export interface ReminderEntry {
  id: string;
  text: string;
  triggerTime: number; // Unix timestamp in milliseconds
  createdAt: number;
  isTriggered: boolean;
  notificationSent: boolean;
}

// Simple IndexedDB wrapper without external dependencies
class SimpleDB {
  private dbName: string;
  private storeName: string;
  private db: IDBDatabase | null = null;

  constructor(dbName: string, storeName: string) {
    this.dbName = dbName;
    this.storeName = storeName;
  }

  async open(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, 1);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          const store = db.createObjectStore(this.storeName, { keyPath: 'id' });
          store.createIndex('by-trigger-time', 'triggerTime');
        }
      };
    });
  }

  async getAll(): Promise<ReminderEntry[]> {
    if (!this.db) return [];
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readonly');
      const store = transaction.objectStore(this.storeName);
      const request = store.getAll();

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
    });
  }

  async add(value: ReminderEntry): Promise<void> {
    if (!this.db) return;
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readwrite');
      const store = transaction.objectStore(this.storeName);
      const request = store.add(value);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  }

  async put(value: ReminderEntry): Promise<void> {
    if (!this.db) return;
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readwrite');
      const store = transaction.objectStore(this.storeName);
      const request = store.put(value);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  }

  async delete(id: string): Promise<void> {
    if (!this.db) return;
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readwrite');
      const store = transaction.objectStore(this.storeName);
      const request = store.delete(id);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  }
}

export class ReminderSystem {
  private static instance: ReminderSystem | null = null;
  private db: SimpleDB | null = null;
  private checkInterval: number | null = null;
  private audioContext: AudioContext | null = null;
  private notificationPermission: NotificationPermission = 'default';

  private constructor() {
    this.initAudioContext();
    this.checkNotificationPermission();
  }

  static getInstance(): ReminderSystem {
    if (!ReminderSystem.instance) {
      ReminderSystem.instance = new ReminderSystem();
    }
    return ReminderSystem.instance;
  }

  // Initialize IndexedDB for reminder storage
  async initialize(): Promise<void> {
    try {
      this.db = new SimpleDB('jarvis-reminders', 'reminders');
      await this.db.open();
      console.log('Reminder system initialized with IndexedDB');
    } catch (error) {
      console.error('Failed to initialize reminder database:', error);
      throw error;
    }
  }

  // Initialize audio context for beep sounds
  private initAudioContext(): void {
    try {
      if (typeof window !== 'undefined' && 'AudioContext' in window) {
        this.audioContext = new AudioContext();
      }
    } catch (error) {
      console.error('Error initializing audio context:', error);
    }
  }

  // Check notification permission status
  private async checkNotificationPermission(): Promise<void> {
    if ('Notification' in window) {
      this.notificationPermission = Notification.permission;
    }
  }

  // Request notification permission
  async requestNotificationPermission(): Promise<boolean> {
    if (!('Notification' in window)) {
      console.warn('Notifications not supported');
      return false;
    }

    if (this.notificationPermission === 'granted') {
      return true;
    }

    try {
      const permission = await Notification.requestPermission();
      this.notificationPermission = permission;
      return permission === 'granted';
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      return false;
    }
  }

  // Parse natural language time input
  parseTimeInput(input: string): number | null {
    const now = new Date();
    const normalized = input.toLowerCase().trim();

    // Pattern: "remind me at 8:30 PM"
    const atTimeMatch = normalized.match(/at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i);
    if (atTimeMatch) {
      let hours = parseInt(atTimeMatch[1]);
      const minutes = atTimeMatch[2] ? parseInt(atTimeMatch[2]) : 0;
      const period = atTimeMatch[3];

      if (period === 'pm' && hours < 12) hours += 12;
      if (period === 'am' && hours === 12) hours = 0;

      const target = new Date(now);
      target.setHours(hours, minutes, 0, 0);

      // If time is in the past, assume tomorrow
      if (target <= now) {
        target.setDate(target.getDate() + 1);
      }

      return target.getTime();
    }

    // Pattern: "remind me after 10 minutes"
    const afterMatch = normalized.match(/after\s+(\d+)\s*(minute|minutes|min|hour|hours|hr)/i);
    if (afterMatch) {
      const value = parseInt(afterMatch[1]);
      const unit = afterMatch[2].toLowerCase();
      
      const target = new Date(now);
      if (unit.startsWith('min')) {
        target.setMinutes(target.getMinutes() + value);
      } else if (unit.startsWith('hour') || unit.startsWith('hr')) {
        target.setHours(target.getHours() + value);
      }

      return target.getTime();
    }

    // Pattern: "remind me on February 2 at 5 PM"
    const onDateMatch = normalized.match(/on\s+(\w+)\s+(\d{1,2})(?:\s+at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?)?/i);
    if (onDateMatch) {
      const monthName = onDateMatch[1];
      const day = parseInt(onDateMatch[2]);
      const hours = onDateMatch[3] ? parseInt(onDateMatch[3]) : 12;
      const minutes = onDateMatch[4] ? parseInt(onDateMatch[4]) : 0;
      const period = onDateMatch[5];

      const monthMap: { [key: string]: number } = {
        'january': 0, 'jan': 0,
        'february': 1, 'feb': 1,
        'march': 2, 'mar': 2,
        'april': 3, 'apr': 3,
        'may': 4,
        'june': 5, 'jun': 5,
        'july': 6, 'jul': 6,
        'august': 7, 'aug': 7,
        'september': 8, 'sep': 8, 'sept': 8,
        'october': 9, 'oct': 9,
        'november': 10, 'nov': 10,
        'december': 11, 'dec': 11,
      };

      const month = monthMap[monthName.toLowerCase()];
      if (month === undefined) return null;

      let finalHours = hours;
      if (period === 'pm' && hours < 12) finalHours += 12;
      if (period === 'am' && hours === 12) finalHours = 0;

      const target = new Date(now.getFullYear(), month, day, finalHours, minutes, 0, 0);

      // If date is in the past, assume next year
      if (target <= now) {
        target.setFullYear(target.getFullYear() + 1);
      }

      return target.getTime();
    }

    // Pattern: "remind me in 30 minutes"
    const inMatch = normalized.match(/in\s+(\d+)\s*(minute|minutes|min|hour|hours|hr)/i);
    if (inMatch) {
      const value = parseInt(inMatch[1]);
      const unit = inMatch[2].toLowerCase();
      
      const target = new Date(now);
      if (unit.startsWith('min')) {
        target.setMinutes(target.getMinutes() + value);
      } else if (unit.startsWith('hour') || unit.startsWith('hr')) {
        target.setHours(target.getHours() + value);
      }

      return target.getTime();
    }

    return null;
  }

  // Add a new reminder
  async addReminder(text: string, triggerTime: number): Promise<ReminderEntry> {
    if (!this.db) {
      throw new Error('Reminder database not initialized');
    }

    const reminder: ReminderEntry = {
      id: `reminder_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      text,
      triggerTime,
      createdAt: Date.now(),
      isTriggered: false,
      notificationSent: false,
    };

    await this.db.add(reminder);
    console.log('Reminder added:', reminder);
    return reminder;
  }

  // Get all reminders
  async getAllReminders(): Promise<ReminderEntry[]> {
    if (!this.db) return [];
    return await this.db.getAll();
  }

  // Get active (not triggered) reminders
  async getActiveReminders(): Promise<ReminderEntry[]> {
    const all = await this.getAllReminders();
    return all.filter(r => !r.isTriggered && r.triggerTime > Date.now());
  }

  // Delete a reminder
  async deleteReminder(id: string): Promise<void> {
    if (!this.db) return;
    await this.db.delete(id);
  }

  // Update a reminder
  async updateReminder(reminder: ReminderEntry): Promise<void> {
    if (!this.db) return;
    await this.db.put(reminder);
  }

  // Play system beep sound
  playBeep(): void {
    if (!this.audioContext) return;

    try {
      const oscillator = this.audioContext.createOscillator();
      const gainNode = this.audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(this.audioContext.destination);

      oscillator.frequency.value = 800;
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.3, this.audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.5);

      oscillator.start(this.audioContext.currentTime);
      oscillator.stop(this.audioContext.currentTime + 0.5);
    } catch (error) {
      console.error('Error playing beep:', error);
    }
  }

  // Show browser notification
  async showNotification(reminder: ReminderEntry): Promise<void> {
    if (!('Notification' in window) || this.notificationPermission !== 'granted') {
      console.warn('Notifications not available or not permitted');
      return;
    }

    try {
      const notification = new Notification('JARVIS Reminder', {
        body: reminder.text,
        icon: '/assets/generated/jarvis-logo-transparent.dim_200x200.png',
        badge: '/assets/generated/jarvis-logo-transparent.dim_200x200.png',
        tag: reminder.id,
        requireInteraction: true,
        silent: false,
      });

      notification.onclick = () => {
        window.focus();
        notification.close();
      };

      console.log('Notification shown:', reminder.text);
    } catch (error) {
      console.error('Error showing notification:', error);
    }
  }

  // Speak reminder using TTS
  speak(text: string): void {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-IN';
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  }

  // Start monitoring reminders
  startMonitoring(): void {
    if (this.checkInterval) return;

    console.log('Starting reminder monitoring');
    this.checkInterval = window.setInterval(async () => {
      await this.checkReminders();
    }, 1000); // Check every second
  }

  // Stop monitoring reminders
  stopMonitoring(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
      console.log('Stopped reminder monitoring');
    }
  }

  // Check for due reminders
  private async checkReminders(): Promise<void> {
    const now = Date.now();
    const reminders = await this.getAllReminders();

    for (const reminder of reminders) {
      if (!reminder.isTriggered && reminder.triggerTime <= now) {
        await this.triggerReminder(reminder);
      }
    }
  }

  // Trigger a reminder
  private async triggerReminder(reminder: ReminderEntry): Promise<void> {
    console.log('Triggering reminder:', reminder.text);

    // Update reminder status
    reminder.isTriggered = true;
    reminder.notificationSent = true;
    await this.updateReminder(reminder);

    // Play beep sound
    this.playBeep();

    // Show notification
    await this.showNotification(reminder);

    // Speak reminder
    const time = new Date(reminder.triggerTime).toLocaleTimeString('en-IN', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
    this.speak(`Sir, it's ${time}. ${reminder.text}`);

    // Dispatch custom event for UI update
    window.dispatchEvent(new CustomEvent('reminder-triggered', { detail: reminder }));
  }

  // Get countdown to next reminder
  getCountdownToReminder(triggerTime: number): { hours: number; minutes: number; seconds: number } {
    const now = Date.now();
    const diff = triggerTime - now;

    if (diff <= 0) {
      return { hours: 0, minutes: 0, seconds: 0 };
    }

    const totalSeconds = Math.floor(diff / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    return { hours, minutes, seconds };
  }

  // Get PWA limitation message
  getPWALimitationMessage(): string {
    return "Sir, reminders work best while the app remains open. PWA limitations prevent background execution when the app is closed.";
  }
}
