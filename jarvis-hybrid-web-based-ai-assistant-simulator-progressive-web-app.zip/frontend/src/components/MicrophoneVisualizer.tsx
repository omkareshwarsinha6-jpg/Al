import { useEffect, useRef } from 'react';

interface MicrophoneVisualizerProps {
  isActive: boolean;
}

const MicrophoneVisualizer = ({ isActive }: MicrophoneVisualizerProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);

  useEffect(() => {
    if (!isActive || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bars = 40;
    const barWidth = canvas.width / bars;
    let phase = 0;

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      for (let i = 0; i < bars; i++) {
        const height = Math.sin(phase + i * 0.3) * 30 + 40;
        const x = i * barWidth;
        const y = (canvas.height - height) / 2;
        
        // Create gradient for neon effect
        const gradient = ctx.createLinearGradient(x, y, x, y + height);
        gradient.addColorStop(0, 'oklch(0.7 0.25 240)');
        gradient.addColorStop(1, 'oklch(0.5 0.25 240)');
        
        ctx.fillStyle = gradient;
        ctx.fillRect(x, y, barWidth - 2, height);
      }
      
      phase += 0.1;
      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current !== null) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isActive]);

  if (!isActive) return null;

  return (
    <div className="flex items-center justify-center">
      <canvas
        ref={canvasRef}
        width={400}
        height={80}
        className="rounded-lg border border-primary/20 bg-background/50"
      />
    </div>
  );
};

export default MicrophoneVisualizer;
