import { User, Bot } from 'lucide-react';

interface ChatMessageProps {
  speaker: 'User' | 'Jarvis';
  message: string;
  isTranscript?: boolean;
}

const ChatMessage = ({ speaker, message, isTranscript = false }: ChatMessageProps) => {
  const isUser = speaker === 'User';

  return (
    <div className={`flex gap-3 mb-4 ${isUser ? 'justify-end' : 'justify-start'} ${isTranscript ? 'opacity-60' : ''}`}>
      {!isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center border border-primary/40">
          <Bot className="w-5 h-5 text-primary" />
        </div>
      )}
      
      <div className={`max-w-[80%] rounded-lg px-4 py-2 ${
        isUser 
          ? 'bg-primary text-primary-foreground message-glow-user' 
          : 'bg-accent/30 text-foreground border border-primary/20 message-glow-jarvis'
      }`}>
        <p className="text-sm font-medium mb-1">{speaker}:</p>
        <p className="text-sm whitespace-pre-wrap">{message}</p>
      </div>

      {isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-secondary/20 flex items-center justify-center border border-secondary/40">
          <User className="w-5 h-5 text-secondary" />
        </div>
      )}
    </div>
  );
};

export default ChatMessage;
