// Multi-step automation editor component for creating and managing automation workflows
// Allows users to define up to 6 sequential tasks with various action types and configurations

import { useState } from 'react';
import { Plus, Trash2, Play, Save, MoveUp, MoveDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import type { AutomationRule, AutomationStep } from './JarvisInterface';

interface AutomationEditorProps {
  rules: AutomationRule[];
  onSave: (rules: AutomationRule[]) => void;
  onTest: (rule: AutomationRule) => void;
}

const AutomationEditor = ({ rules, onSave, onTest }: AutomationEditorProps) => {
  const [editingRule, setEditingRule] = useState<AutomationRule | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  // Start creating new automation
  const startNewAutomation = () => {
    const newRule: AutomationRule = {
      id: `auto_${Date.now()}`,
      name: 'New Automation',
      triggerPhrase: '',
      steps: [],
      enabled: true,
    };
    setEditingRule(newRule);
    setIsCreating(true);
  };

  // Save current automation
  const saveCurrentAutomation = () => {
    if (!editingRule) return;

    if (!editingRule.name.trim()) {
      toast.error('Please enter an automation name');
      return;
    }

    if (!editingRule.triggerPhrase.trim()) {
      toast.error('Please enter a trigger phrase');
      return;
    }

    if (editingRule.steps.length === 0) {
      toast.error('Please add at least one step');
      return;
    }

    let updatedRules: AutomationRule[];
    
    if (isCreating) {
      updatedRules = [...rules, editingRule];
    } else {
      updatedRules = rules.map(r => r.id === editingRule.id ? editingRule : r);
    }

    onSave(updatedRules);
    setEditingRule(null);
    setIsCreating(false);
    toast.success('Automation saved successfully');
  };

  // Delete automation
  const deleteAutomation = (id: string) => {
    const updatedRules = rules.filter(r => r.id !== id);
    onSave(updatedRules);
    toast.success('Automation deleted');
  };

  // Toggle automation enabled state
  const toggleAutomation = (id: string) => {
    const updatedRules = rules.map(r => 
      r.id === id ? { ...r, enabled: !r.enabled } : r
    );
    onSave(updatedRules);
  };

  // Add step to current automation
  const addStep = () => {
    if (!editingRule) return;

    if (editingRule.steps.length >= 6) {
      toast.error('Maximum 6 steps per automation');
      return;
    }

    const newStep: AutomationStep = {
      type: 'speak',
      speech: '',
    };

    setEditingRule({
      ...editingRule,
      steps: [...editingRule.steps, newStep],
    });
  };

  // Remove step from current automation
  const removeStep = (index: number) => {
    if (!editingRule) return;

    setEditingRule({
      ...editingRule,
      steps: editingRule.steps.filter((_, i) => i !== index),
    });
  };

  // Move step up
  const moveStepUp = (index: number) => {
    if (!editingRule || index === 0) return;

    const newSteps = [...editingRule.steps];
    [newSteps[index - 1], newSteps[index]] = [newSteps[index], newSteps[index - 1]];

    setEditingRule({
      ...editingRule,
      steps: newSteps,
    });
  };

  // Move step down
  const moveStepDown = (index: number) => {
    if (!editingRule || index === editingRule.steps.length - 1) return;

    const newSteps = [...editingRule.steps];
    [newSteps[index], newSteps[index + 1]] = [newSteps[index + 1], newSteps[index]];

    setEditingRule({
      ...editingRule,
      steps: newSteps,
    });
  };

  // Update step
  const updateStep = (index: number, updates: Partial<AutomationStep>) => {
    if (!editingRule) return;

    const newSteps = editingRule.steps.map((step, i) => 
      i === index ? { ...step, ...updates } : step
    );

    setEditingRule({
      ...editingRule,
      steps: newSteps,
    });
  };

  return (
    <div className="space-y-4">
      {/* Automation List */}
      {!editingRule && (
        <>
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-primary">Your Automations ({rules.length})</h3>
            <Button onClick={startNewAutomation} className="bg-accent hover:bg-accent/90">
              <Plus className="w-4 h-4 mr-2" />
              New Automation
            </Button>
          </div>

          <ScrollArea className="h-[400px]">
            {rules.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <p>No automations yet. Create your first one!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {rules.map(rule => (
                  <Card key={rule.id} className="border-primary/20">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-base text-primary">{rule.name}</CardTitle>
                          <p className="text-sm text-muted-foreground mt-1">
                            Trigger: "{rule.triggerPhrase}"
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {rule.steps.length} step{rule.steps.length !== 1 ? 's' : ''}
                          </p>
                        </div>
                        <Switch
                          checked={rule.enabled}
                          onCheckedChange={() => toggleAutomation(rule.id)}
                        />
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setEditingRule(rule);
                            setIsCreating(false);
                          }}
                          className="flex-1"
                        >
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onTest(rule)}
                          className="flex-1"
                        >
                          <Play className="w-3 h-3 mr-1" />
                          Test
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteAutomation(rule.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </ScrollArea>
        </>
      )}

      {/* Automation Editor */}
      {editingRule && (
        <>
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-primary">
              {isCreating ? 'Create Automation' : 'Edit Automation'}
            </h3>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setEditingRule(null);
                  setIsCreating(false);
                }}
              >
                Cancel
              </Button>
              <Button onClick={saveCurrentAutomation} className="bg-primary hover:bg-primary/90">
                <Save className="w-4 h-4 mr-2" />
                Save
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            {/* Basic Info */}
            <div className="space-y-3">
              <div>
                <Label htmlFor="automation-name">Automation Name</Label>
                <Input
                  id="automation-name"
                  value={editingRule.name}
                  onChange={(e) => setEditingRule({ ...editingRule, name: e.target.value })}
                  placeholder="e.g., Morning Routine"
                  className="mt-1 border-primary/20 focus:border-primary"
                />
              </div>

              <div>
                <Label htmlFor="trigger-phrase">Trigger Phrase</Label>
                <Input
                  id="trigger-phrase"
                  value={editingRule.triggerPhrase}
                  onChange={(e) => setEditingRule({ ...editingRule, triggerPhrase: e.target.value })}
                  placeholder="e.g., start morning routine"
                  className="mt-1 border-primary/20 focus:border-primary"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Say this phrase to trigger the automation
                </p>
              </div>
            </div>

            <Separator className="bg-primary/20" />

            {/* Steps */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <Label>Automation Steps ({editingRule.steps.length}/6)</Label>
                <Button
                  onClick={addStep}
                  size="sm"
                  disabled={editingRule.steps.length >= 6}
                  className="bg-accent hover:bg-accent/90"
                >
                  <Plus className="w-3 h-3 mr-1" />
                  Add Step
                </Button>
              </div>

              <ScrollArea className="h-[300px]">
                {editingRule.steps.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No steps yet. Add your first step!</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {editingRule.steps.map((step, index) => (
                      <Card key={index} className="border-primary/20">
                        <CardContent className="pt-4">
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-sm font-medium text-primary">
                                Step {index + 1}
                              </span>
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => moveStepUp(index)}
                                  disabled={index === 0}
                                  className="h-7 w-7"
                                >
                                  <MoveUp className="w-3 h-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => moveStepDown(index)}
                                  disabled={index === editingRule.steps.length - 1}
                                  className="h-7 w-7"
                                >
                                  <MoveDown className="w-3 h-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => removeStep(index)}
                                  className="h-7 w-7 text-destructive hover:text-destructive"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>

                            <div>
                              <Label>Action Type</Label>
                              <Select
                                value={step.type}
                                onValueChange={(value: any) => updateStep(index, { type: value })}
                              >
                                <SelectTrigger className="mt-1 border-primary/20">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="speak">Speak Text</SelectItem>
                                  <SelectItem value="open_app">Open App</SelectItem>
                                  <SelectItem value="search">Search</SelectItem>
                                  <SelectItem value="system_action">System Action</SelectItem>
                                  <SelectItem value="delay">Delay</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>

                            {step.type === 'speak' && (
                              <div>
                                <Label>Text to Speak</Label>
                                <Input
                                  value={step.speech || ''}
                                  onChange={(e) => updateStep(index, { speech: e.target.value })}
                                  placeholder="Enter text to speak"
                                  className="mt-1 border-primary/20 focus:border-primary"
                                />
                              </div>
                            )}

                            {step.type === 'open_app' && (
                              <div>
                                <Label>App Name</Label>
                                <Input
                                  value={step.target || ''}
                                  onChange={(e) => updateStep(index, { target: e.target.value })}
                                  placeholder="e.g., youtube, whatsapp, gmail"
                                  className="mt-1 border-primary/20 focus:border-primary"
                                />
                              </div>
                            )}

                            {step.type === 'search' && (
                              <div>
                                <Label>Search Query</Label>
                                <Input
                                  value={step.target || ''}
                                  onChange={(e) => updateStep(index, { target: e.target.value })}
                                  placeholder="Enter search query"
                                  className="mt-1 border-primary/20 focus:border-primary"
                                />
                              </div>
                            )}

                            {step.type === 'system_action' && (
                              <div>
                                <Label>System Action</Label>
                                <Select
                                  value={step.target || 'wifi'}
                                  onValueChange={(value) => updateStep(index, { target: value })}
                                >
                                  <SelectTrigger className="mt-1 border-primary/20">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="wifi">WiFi</SelectItem>
                                    <SelectItem value="bluetooth">Bluetooth</SelectItem>
                                    <SelectItem value="settings">Settings</SelectItem>
                                    <SelectItem value="volume">Volume</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            )}

                            {step.type === 'delay' && (
                              <div>
                                <Label>Delay (milliseconds)</Label>
                                <Input
                                  type="number"
                                  value={step.delay || 1000}
                                  onChange={(e) => updateStep(index, { delay: parseInt(e.target.value) || 1000 })}
                                  placeholder="1000"
                                  className="mt-1 border-primary/20 focus:border-primary"
                                />
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default AutomationEditor;
