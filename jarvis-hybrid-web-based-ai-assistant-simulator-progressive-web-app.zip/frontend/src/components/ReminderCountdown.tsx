// Reminder countdown display component with dismissible beep alert
// Shows real-time countdown timer with hours, minutes, seconds and OFF button

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Bell, X } from 'lucide-react';
import type { Reminder } from '../lib/BackgroundClock';

interface ReminderCountdownProps {
  reminder: Reminder;
  countdown: { hours: number; minutes: number; seconds: number };
  onDismiss: (reminderId: string) => void;
}

const ReminderCountdown = ({ reminder, countdown, onDismiss }: ReminderCountdownProps) => {
  const [isTriggered, setIsTriggered] = useState(reminder.isTriggered || false);

  useEffect(() => {
    setIsTriggered(reminder.isTriggered || false);
  }, [reminder.isTriggered]);

  const formatTime = (value: number): string => {
    return value.toString().padStart(2, '0');
  };

  const isCountdownZero = countdown.hours === 0 && countdown.minutes === 0 && countdown.seconds === 0;

  return (
    <Card className={`p-4 border-2 ${isTriggered ? 'border-destructive bg-destructive/10 animate-pulse' : 'border-accent bg-accent/10'} neon-glow`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <Bell className={`w-5 h-5 ${isTriggered ? 'text-destructive animate-bounce' : 'text-accent'}`} />
          <div>
            <p className="text-sm font-semibold text-primary">{reminder.message}</p>
            <p className="text-xs text-muted-foreground">Target: {reminder.time}</p>
          </div>
        </div>
      </div>

      {!isCountdownZero && !isTriggered && (
        <div className="flex items-center justify-center gap-2 mb-3">
          <div className="text-center">
            <div className="text-3xl font-bold text-accent neon-text">
              {formatTime(countdown.hours)}
            </div>
            <div className="text-xs text-muted-foreground">Hours</div>
          </div>
          <div className="text-3xl font-bold text-accent">:</div>
          <div className="text-center">
            <div className="text-3xl font-bold text-accent neon-text">
              {formatTime(countdown.minutes)}
            </div>
            <div className="text-xs text-muted-foreground">Minutes</div>
          </div>
          <div className="text-3xl font-bold text-accent">:</div>
          <div className="text-center">
            <div className="text-3xl font-bold text-accent neon-text">
              {formatTime(countdown.seconds)}
            </div>
            <div className="text-xs text-muted-foreground">Seconds</div>
          </div>
        </div>
      )}

      {isTriggered && (
        <div className="mb-3">
          <p className="text-center text-lg font-bold text-destructive animate-pulse">
            🔔 TIME'S UP! 🔔
          </p>
        </div>
      )}

      {isTriggered && (
        <Button
          onClick={() => onDismiss(reminder.id)}
          className="w-full bg-destructive hover:bg-destructive/90 text-destructive-foreground font-bold"
          size="lg"
        >
          <X className="w-5 h-5 mr-2" />
          OFF
        </Button>
      )}
    </Card>
  );
};

export default ReminderCountdown;
