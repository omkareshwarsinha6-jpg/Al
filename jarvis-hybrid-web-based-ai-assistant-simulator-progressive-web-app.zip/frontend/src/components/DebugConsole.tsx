// Debug console component for displaying system logs and command execution history
// Shows real-time debugging information with color-coded log types including intent and memory logs

import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

interface DebugLog {
  timestamp: number;
  type: 'command' | 'automation' | 'error' | 'info' | 'intent' | 'memory';
  message: string;
}

interface DebugConsoleProps {
  logs: DebugLog[];
}

const DebugConsole = ({ logs }: DebugConsoleProps) => {
  const getLogColor = (type: string) => {
    switch (type) {
      case 'command':
        return 'bg-primary/20 text-primary border-primary/50';
      case 'automation':
        return 'bg-accent/20 text-accent border-accent/50';
      case 'error':
        return 'bg-destructive/20 text-destructive border-destructive/50';
      case 'info':
        return 'bg-muted/20 text-muted-foreground border-muted/50';
      case 'intent':
        return 'bg-blue-500/20 text-blue-500 border-blue-500/50';
      case 'memory':
        return 'bg-purple-500/20 text-purple-500 border-purple-500/50';
      default:
        return 'bg-muted/20 text-muted-foreground border-muted/50';
    }
  };

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-IN', { 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-primary">Debug Logs ({logs.length})</h3>
        <div className="flex gap-2 flex-wrap">
          <Badge variant="outline" className="border-primary/50">
            <span className="w-2 h-2 rounded-full bg-primary mr-2"></span>
            Command
          </Badge>
          <Badge variant="outline" className="border-accent/50">
            <span className="w-2 h-2 rounded-full bg-accent mr-2"></span>
            Automation
          </Badge>
          <Badge variant="outline" className="border-blue-500/50">
            <span className="w-2 h-2 rounded-full bg-blue-500 mr-2"></span>
            Intent
          </Badge>
          <Badge variant="outline" className="border-purple-500/50">
            <span className="w-2 h-2 rounded-full bg-purple-500 mr-2"></span>
            Memory
          </Badge>
          <Badge variant="outline" className="border-destructive/50">
            <span className="w-2 h-2 rounded-full bg-destructive mr-2"></span>
            Error
          </Badge>
          <Badge variant="outline" className="border-muted/50">
            <span className="w-2 h-2 rounded-full bg-muted-foreground mr-2"></span>
            Info
          </Badge>
        </div>
      </div>

      <ScrollArea className="h-[400px] border border-primary/20 rounded-lg p-4 bg-background/50">
        {logs.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <p>No logs yet. Start using JARVIS to see debug information.</p>
          </div>
        ) : (
          <div className="space-y-2 font-mono text-sm">
            {logs.map((log, index) => (
              <div
                key={index}
                className={`p-3 rounded border ${getLogColor(log.type)}`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className="text-xs">
                        {log.type.toUpperCase()}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {formatTime(log.timestamp)}
                      </span>
                    </div>
                    <p className="text-sm break-words">{log.message}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>

      <p className="text-xs text-muted-foreground">
        Logs are kept for the current session only. Maximum 100 entries.
      </p>
    </div>
  );
};

export default DebugConsole;
