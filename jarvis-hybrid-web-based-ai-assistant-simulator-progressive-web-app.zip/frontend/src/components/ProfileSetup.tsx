// Profile setup component that collects user name after internal authentication
// Speaks appropriate greeting based on admin/guest role with time-based salutation
// Saves profile to backend with role determined by internal auth system

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { useSaveCallerUserProfile } from '../hooks/useQueries';
import type { UserProfile } from '../backend';

interface ProfileSetupProps {
  isAdmin?: boolean; // Flag to determine if user is admin (from internal auth)
}

const ProfileSetup = ({ isAdmin = false }: ProfileSetupProps) => {
  // Store user's name input
  const [name, setName] = useState('');
  
  // Get mutation function to save profile to backend
  const saveProfileMutation = useSaveCallerUserProfile();
  
  // Reference to speech synthesis API
  const synthRef = useRef<SpeechSynthesis | null>(null);
  
  // Flag to prevent greeting from being spoken multiple times
  const hasSpokenRef = useRef(false);

  // Initialize speech synthesis on component mount
  useEffect(() => {
    if ('speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Speak text using Web Speech API (only once per session)
  const speak = (text: string) => {
    // Don't speak if already spoken or synthesis not available
    if (!synthRef.current || hasSpokenRef.current) return;
    
    // Cancel any ongoing speech
    synthRef.current.cancel();
    
    // Create new utterance with Indian English voice
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-IN';
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    
    // Speak the text
    synthRef.current.speak(utterance);
    
    // Mark as spoken to prevent repeats
    hasSpokenRef.current = true;
  };

  // Get time-based greeting (morning/afternoon/evening)
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  // Handle form submission to save user profile
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate name input
    if (!name.trim()) {
      toast.error('Please enter your name');
      return;
    }

    // Create user profile object with role from internal auth and timestamp
    const profile: UserProfile = {
      name: name.trim(),
      role: isAdmin ? 'admin' : 'guest',
      loginTimestamp: BigInt(Date.now()),
    };

    try {
      // Save profile to backend
      await saveProfileMutation.mutateAsync(profile);
      
      // Generate appropriate greeting based on role
      const greeting = isAdmin
        ? "Welcome back sir, you are logged in as admin. Now you can access source code directly."
        : `${getGreeting()} sir, I'm Jarvis, your AI voice assistant.`;
      
      // Speak and display greeting
      speak(greeting);
      toast.success(greeting);
    } catch (error) {
      console.error('Error saving profile:', error);
      toast.error('Failed to save profile. Please try again.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-accent/10 p-4">
      <Card className="w-full max-w-md border-primary/30 bg-card/80 backdrop-blur-sm">
        <CardHeader className="text-center">
          {/* JARVIS logo with pulse animation */}
          <img 
            src="/assets/generated/jarvis-logo-transparent.dim_200x200.png" 
            alt="JARVIS" 
            className="w-20 h-20 mx-auto mb-4 animate-pulse" 
          />
          <CardTitle className="text-2xl text-primary">Welcome to JARVIS</CardTitle>
          <CardDescription>Please tell me your name</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Name input field */}
            <div className="space-y-2">
              <Label htmlFor="name">Your Name</Label>
              <Input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name"
                className="border-primary/20 focus:border-primary"
                autoFocus
              />
            </div>
            {/* Submit button with loading state */}
            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90"
              disabled={saveProfileMutation.isPending}
            >
              {saveProfileMutation.isPending ? 'Saving...' : 'Continue'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfileSetup;
