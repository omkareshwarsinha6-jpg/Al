// Command scheduler component for time-based queued task execution
// Allows users to schedule commands for future execution with local persistence

import { useState, useEffect } from 'react';
import { Clock, Plus, Trash2, Play, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { MemoryManager } from '../lib/MemoryManager';

interface CommandSchedulerProps {
  onExecuteCommand: (command: string) => void;
}

const CommandScheduler = ({ onExecuteCommand }: CommandSchedulerProps) => {
  const [tasks, setTasks] = useState<Array<{ id: string; task: string; scheduledTime: number; executed: boolean }>>([]);
  const [newTask, setNewTask] = useState('');
  const [delayMinutes, setDelayMinutes] = useState(5);

  // Load tasks on mount
  useEffect(() => {
    loadTasks();
    
    // Check for pending tasks every 10 seconds
    const interval = setInterval(() => {
      checkPendingTasks();
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  // Load tasks from memory
  const loadTasks = () => {
    const allTasks = MemoryManager.getAllScheduledTasks();
    setTasks(allTasks);
  };

  // Check and execute pending tasks
  const checkPendingTasks = () => {
    const pending = MemoryManager.getPendingTasks();
    
    pending.forEach(task => {
      toast.info(`Executing scheduled task: ${task.task}`);
      onExecuteCommand(task.task);
      MemoryManager.markTaskExecuted(task.id);
    });

    if (pending.length > 0) {
      loadTasks();
    }
  };

  // Add new scheduled task
  const addTask = () => {
    if (!newTask.trim()) {
      toast.error('Please enter a command');
      return;
    }

    if (delayMinutes < 1) {
      toast.error('Delay must be at least 1 minute');
      return;
    }

    const scheduledTime = Date.now() + (delayMinutes * 60 * 1000);
    MemoryManager.addScheduledTask(newTask, scheduledTime);
    
    toast.success(`Task scheduled for ${delayMinutes} minute${delayMinutes !== 1 ? 's' : ''} from now`);
    
    setNewTask('');
    setDelayMinutes(5);
    loadTasks();
  };

  // Remove task
  const removeTask = (id: string) => {
    MemoryManager.removeScheduledTask(id);
    toast.success('Task removed');
    loadTasks();
  };

  // Execute task immediately
  const executeNow = (task: { id: string; task: string }) => {
    onExecuteCommand(task.task);
    MemoryManager.markTaskExecuted(task.id);
    toast.success('Task executed');
    loadTasks();
  };

  // Format time remaining
  const formatTimeRemaining = (scheduledTime: number): string => {
    const now = Date.now();
    const diff = scheduledTime - now;

    if (diff < 0) return 'Ready';

    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ${hours % 24}h`;
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    return `${minutes}m`;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <Clock className="w-5 h-5 text-accent" />
        <h3 className="text-lg font-semibold text-primary">Command Scheduler</h3>
      </div>

      {/* Add new task */}
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="text-base text-primary">Schedule New Command</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label htmlFor="task-command">Command</Label>
            <Input
              id="task-command"
              value={newTask}
              onChange={(e) => setNewTask(e.target.value)}
              placeholder="e.g., open YouTube"
              className="mt-1 border-primary/20 focus:border-primary"
            />
          </div>

          <div>
            <Label htmlFor="task-delay">Delay (minutes)</Label>
            <Input
              id="task-delay"
              type="number"
              value={delayMinutes}
              onChange={(e) => setDelayMinutes(parseInt(e.target.value) || 1)}
              min="1"
              className="mt-1 border-primary/20 focus:border-primary"
            />
          </div>

          <Button onClick={addTask} className="w-full bg-accent hover:bg-accent/90">
            <Plus className="w-4 h-4 mr-2" />
            Schedule Task
          </Button>
        </CardContent>
      </Card>

      {/* Task list */}
      <ScrollArea className="h-[300px]">
        {tasks.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Clock className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No scheduled tasks</p>
          </div>
        ) : (
          <div className="space-y-2">
            {tasks.map((task) => (
              <Card key={task.id} className="border-primary/20">
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <p className="text-sm font-medium text-primary">{task.task}</p>
                      <div className="flex items-center gap-2 mt-1">
                        {task.executed ? (
                          <Badge variant="outline" className="border-green-500 text-green-500">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Executed
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="border-accent text-accent">
                            {formatTimeRemaining(task.scheduledTime)}
                          </Badge>
                        )}
                        <span className="text-xs text-muted-foreground">
                          {new Date(task.scheduledTime).toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <div className="flex gap-1">
                      {!task.executed && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => executeNow(task)}
                          className="h-8 w-8"
                        >
                          <Play className="w-3 h-3" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeTask(task.id)}
                        className="h-8 w-8 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
};

export default CommandScheduler;
