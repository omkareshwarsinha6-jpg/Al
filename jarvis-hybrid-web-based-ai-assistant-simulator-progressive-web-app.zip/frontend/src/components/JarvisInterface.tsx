import { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Send, Settings, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { useGetApiKey, useStoreApiKey, useGetConversationHistory, useStoreConversationHistory } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import type { ConversationEntry } from '../backend';
import ChatMessage from './ChatMessage';
import MicrophoneVisualizer from './MicrophoneVisualizer';
import { Heart } from 'lucide-react';

interface Message {
  speaker: 'User' | 'Jarvis';
  message: string;
  timestamp: number;
}

const JarvisInterface = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [tempApiKey, setTempApiKey] = useState('');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  const recognitionRef = useRef<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const restartTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const { identity, login, isLoginSuccess } = useInternetIdentity();
  const { data: storedApiKey } = useGetApiKey();
  const storeApiKeyMutation = useStoreApiKey();
  const { data: conversationHistory } = useGetConversationHistory();
  const storeConversationMutation = useStoreConversationHistory();

  // Initialize speech synthesis
  useEffect(() => {
    if ('speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Load stored API key
  useEffect(() => {
    if (storedApiKey) {
      setApiKey(storedApiKey);
      setTempApiKey(storedApiKey);
    }
  }, [storedApiKey]);

  // Load conversation history
  useEffect(() => {
    if (conversationHistory && conversationHistory.length > 0) {
      const loadedMessages = conversationHistory.map(entry => ({
        speaker: entry.speaker as 'User' | 'Jarvis',
        message: entry.message,
        timestamp: Number(entry.timestamp),
      }));
      setMessages(loadedMessages);
    }
  }, [conversationHistory]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, transcript]);

  // Initialize speech recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      toast.error('Speech recognition not supported in this browser. Please use Chrome or Edge.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-IN';

    recognition.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript + ' ';
        } else {
          interimTranscript += transcript;
        }
      }

      if (finalTranscript) {
        setTranscript('');
        handleVoiceCommand(finalTranscript.trim());
      } else {
        setTranscript(interimTranscript);
      }
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      
      if (event.error === 'not-allowed') {
        toast.error('Microphone permission required. Please allow microphone access.');
        setIsListening(false);
      } else if (event.error === 'network') {
        toast.error('Network issue. Please check your internet connection.');
      } else if (event.error === 'no-speech') {
        // Silently restart on no-speech
        if (isListening) {
          restartRecognition();
        }
      }
    };

    recognition.onend = () => {
      if (isListening) {
        restartRecognition();
      }
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current);
      }
    };
  }, [isListening]);

  const restartRecognition = () => {
    if (restartTimeoutRef.current) {
      clearTimeout(restartTimeoutRef.current);
    }
    
    restartTimeoutRef.current = setTimeout(() => {
      if (recognitionRef.current && isListening) {
        try {
          recognitionRef.current.start();
        } catch (error) {
          console.error('Error restarting recognition:', error);
        }
      }
    }, 100);
  };

  const toggleListening = () => {
    if (!recognitionRef.current) {
      toast.error('Speech recognition not available');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
      setTranscript('');
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current);
      }
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
        toast.success('Listening...');
      } catch (error) {
        console.error('Error starting recognition:', error);
        toast.error('Failed to start listening');
      }
    }
  };

  const speak = (text: string) => {
    if (!synthRef.current) return;

    // Cancel any ongoing speech
    synthRef.current.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-IN';
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    synthRef.current.speak(utterance);
  };

  const addMessage = (speaker: 'User' | 'Jarvis', message: string) => {
    const newMessage: Message = {
      speaker,
      message,
      timestamp: Date.now(),
    };
    
    setMessages(prev => {
      const updated = [...prev, newMessage];
      
      // Store in backend if authenticated
      if (identity) {
        const historyEntries: ConversationEntry[] = updated.map(msg => ({
          speaker: msg.speaker,
          message: msg.message,
          timestamp: BigInt(msg.timestamp),
        }));
        storeConversationMutation.mutate(historyEntries);
      }
      
      return updated;
    });
  };

  const handleVoiceCommand = async (command: string) => {
    if (!command.trim()) return;

    addMessage('User', command);
    await processCommand(command);
  };

  const handleTextSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    addMessage('User', inputText);
    await processCommand(inputText);
    setInputText('');
  };

  const processCommand = async (command: string) => {
    const lowerCommand = command.toLowerCase();

    // Greetings
    if (lowerCommand.match(/^(hello|hi|hey|good morning|good afternoon|good evening)/)) {
      const response = getGreetingResponse();
      addMessage('Jarvis', response);
      speak(response);
      return;
    }

    // Time query
    if (lowerCommand.includes('time')) {
      const time = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
      const response = `The current time is ${time}`;
      addMessage('Jarvis', response);
      speak(response);
      return;
    }

    // Google Search
    if (lowerCommand.match(/search (.*) (on|in) google/)) {
      const match = lowerCommand.match(/search (.*) (on|in) google/);
      if (match) {
        const query = match[1];
        const response = `Searching Google for ${query}`;
        addMessage('Jarvis', response);
        speak(response);
        window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_blank');
        return;
      }
    }

    if (lowerCommand.match(/^(search|find|google) (.*)/)) {
      const match = lowerCommand.match(/^(search|find|google) (.*)/);
      if (match) {
        const query = match[2].replace(/(on|in) google$/, '').trim();
        const response = `Searching Google for ${query}`;
        addMessage('Jarvis', response);
        speak(response);
        window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_blank');
        return;
      }
    }

    // Wikipedia Search
    if (lowerCommand.match(/search (.*) (on|in) wikipedia/)) {
      const match = lowerCommand.match(/search (.*) (on|in) wikipedia/);
      if (match) {
        const query = match[1];
        await searchWikipedia(query);
        return;
      }
    }

    if (lowerCommand.match(/what is (.*)/)) {
      const match = lowerCommand.match(/what is (.*)/);
      if (match) {
        const query = match[1];
        await searchWikipedia(query);
        return;
      }
    }

    // Open apps
    if (lowerCommand.match(/open (.*)/)) {
      const match = lowerCommand.match(/open (.*)/);
      if (match) {
        const appCommand = match[1];
        await handleOpenApp(appCommand);
        return;
      }
    }

    // DeepSeek AI or fallback
    if (apiKey) {
      await queryDeepSeek(command);
    } else {
      const response = "I can help you with searches, opening apps, and answering questions. Try asking me to search something on Google or Wikipedia, or set up your DeepSeek API key in settings for AI-powered responses.";
      addMessage('Jarvis', response);
      speak(response);
    }
  };

  const getGreetingResponse = () => {
    const hour = new Date().getHours();
    const greetings = [
      "Hello! How can I assist you today?",
      "Hi there! What can I do for you?",
      "Greetings! I'm here to help.",
    ];
    
    if (hour < 12) {
      return "Good morning! How may I assist you?";
    } else if (hour < 18) {
      return "Good afternoon! What can I help you with?";
    } else {
      return "Good evening! How can I be of service?";
    }
  };

  const searchWikipedia = async (query: string) => {
    try {
      const response = await fetch(
        `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`
      );
      
      if (response.ok) {
        const data = await response.json();
        const summary = data.extract || "I couldn't find information about that.";
        const sentences = summary.split('. ').slice(0, 2).join('. ') + '.';
        addMessage('Jarvis', sentences);
        speak(sentences);
      } else {
        const fallback = `I couldn't find information about ${query} on Wikipedia.`;
        addMessage('Jarvis', fallback);
        speak(fallback);
      }
    } catch (error) {
      const errorMsg = 'Network issue. Please check your internet connection.';
      addMessage('Jarvis', errorMsg);
      speak(errorMsg);
    }
  };

  const handleOpenApp = async (appCommand: string) => {
    const apps: { [key: string]: string } = {
      'whatsapp': 'https://web.whatsapp.com',
      'youtube': 'https://www.youtube.com',
      'gmail': 'https://mail.google.com',
      'instagram': 'https://www.instagram.com',
      'facebook': 'https://www.facebook.com',
      'twitter': 'https://twitter.com',
      'linkedin': 'https://www.linkedin.com',
      'github': 'https://github.com',
    };

    // Check for YouTube search
    if (appCommand.includes('youtube') && appCommand.includes('search')) {
      const match = appCommand.match(/youtube.*search (.*)/);
      if (match) {
        const query = match[1];
        const response = `Opening YouTube and searching for ${query}`;
        addMessage('Jarvis', response);
        speak(response);
        window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`, '_blank');
        return;
      }
    }

    // Find matching app
    for (const [key, url] of Object.entries(apps)) {
      if (appCommand.includes(key)) {
        const response = `Opening ${key.charAt(0).toUpperCase() + key.slice(1)}`;
        addMessage('Jarvis', response);
        speak(response);
        window.open(url, '_blank');
        return;
      }
    }

    const response = "I'm not sure which app you want to open. Try saying 'Open YouTube' or 'Open WhatsApp'.";
    addMessage('Jarvis', response);
    speak(response);
  };

  const queryDeepSeek = async (query: string) => {
    try {
      const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: 'deepseek-chat',
          messages: [
            { role: 'system', content: 'You are JARVIS, a helpful AI assistant. Keep responses concise and friendly.' },
            { role: 'user', content: query }
          ],
          temperature: 0.7,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const answer = data.choices[0].message.content;
        addMessage('Jarvis', answer);
        speak(answer);
      } else {
        throw new Error('API request failed');
      }
    } catch (error) {
      const fallback = "I'm having trouble connecting to my AI service. Let me search that for you instead.";
      addMessage('Jarvis', fallback);
      speak(fallback);
      window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_blank');
    }
  };

  const saveApiKey = () => {
    setApiKey(tempApiKey);
    if (identity) {
      storeApiKeyMutation.mutate(tempApiKey);
      toast.success('API key saved successfully');
    } else {
      toast.success('API key saved locally (login to sync across devices)');
    }
    setIsSettingsOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background via-background to-accent/5">
      {/* Header */}
      <header className="border-b border-primary/20 bg-background/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/assets/generated/jarvis-logo-transparent.dim_200x200.png" alt="JARVIS" className="w-12 h-12 animate-pulse" />
            <div>
              <h1 className="text-2xl font-bold text-primary neon-text">Om's JARVIS</h1>
              <p className="text-xs text-muted-foreground">Voice Assistant</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {!identity ? (
              <Button onClick={login} variant="outline" size="sm" className="border-primary/50 hover:border-primary">
                Login
              </Button>
            ) : (
              <span className="text-xs text-primary">Connected</span>
            )}
            
            <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="hover:bg-primary/10">
                  <Settings className="w-5 h-5" />
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-primary/20">
                <DialogHeader>
                  <DialogTitle className="text-primary">Settings</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="apiKey">DeepSeek API Key (Optional)</Label>
                    <Input
                      id="apiKey"
                      type="password"
                      value={tempApiKey}
                      onChange={(e) => setTempApiKey(e.target.value)}
                      placeholder="sk-..."
                      className="mt-2 border-primary/20 focus:border-primary"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Get your API key from deepseek.com
                    </p>
                  </div>
                  <Button onClick={saveApiKey} className="w-full bg-primary hover:bg-primary/90">
                    Save Settings
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6 flex flex-col max-w-4xl">
        {/* Chat Area */}
        <div className="flex-1 mb-6 rounded-lg border border-primary/20 bg-card/50 backdrop-blur-sm overflow-hidden flex flex-col">
          <ScrollArea className="flex-1 p-4" ref={scrollRef}>
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-center py-12">
                <img src="/assets/generated/jarvis-interface.dim_400x400.png" alt="JARVIS Interface" className="w-32 h-32 mb-4 opacity-50" />
                <h2 className="text-xl font-semibold text-primary mb-2">Welcome to JARVIS</h2>
                <p className="text-muted-foreground max-w-md">
                  Your personal AI assistant. Click the microphone to start voice commands or type your message below.
                </p>
              </div>
            )}
            
            {messages.map((msg, index) => (
              <ChatMessage key={index} speaker={msg.speaker} message={msg.message} />
            ))}
            
            {transcript && (
              <ChatMessage speaker="User" message={transcript} isTranscript />
            )}
          </ScrollArea>
        </div>

        {/* Microphone Visualizer */}
        {isListening && (
          <div className="mb-4">
            <MicrophoneVisualizer isActive={isListening} />
          </div>
        )}

        {/* Input Area */}
        <div className="space-y-4">
          <div className="flex items-center justify-center gap-4">
            <Button
              onClick={toggleListening}
              size="lg"
              className={`rounded-full w-16 h-16 ${
                isListening
                  ? 'bg-destructive hover:bg-destructive/90 animate-pulse'
                  : 'bg-primary hover:bg-primary/90'
              } neon-glow`}
            >
              {isListening ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </Button>
          </div>

          <form onSubmit={handleTextSubmit} className="flex gap-2">
            <Input
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 border-primary/20 focus:border-primary bg-background/50"
            />
            <Button type="submit" size="icon" className="bg-primary hover:bg-primary/90">
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-primary/20 bg-background/80 backdrop-blur-sm py-4">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          © 2025. Built with <Heart className="inline w-4 h-4 text-destructive fill-destructive" /> using{' '}
          <a href="https://caffeine.ai" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
            caffeine.ai
          </a>
        </div>
      </footer>
    </div>
  );
};

export default JarvisInterface;
