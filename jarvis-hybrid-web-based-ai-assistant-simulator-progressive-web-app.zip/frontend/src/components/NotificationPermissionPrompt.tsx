// Notification permission prompt component with neon styling
// Handles browser notification permission requests with clear explanations

import { useState } from 'react';
import { Bell, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ReminderSystem } from '../lib/ReminderSystem';

interface NotificationPermissionPromptProps {
  onPermissionGranted: () => void;
  onDismiss: () => void;
}

const NotificationPermissionPrompt = ({ onPermissionGranted, onDismiss }: NotificationPermissionPromptProps) => {
  const [isRequesting, setIsRequesting] = useState(false);

  const handleRequestPermission = async () => {
    setIsRequesting(true);
    const reminderSystem = ReminderSystem.getInstance();
    const granted = await reminderSystem.requestNotificationPermission();
    
    if (granted) {
      onPermissionGranted();
    } else {
      onDismiss();
    }
    setIsRequesting(false);
  };

  return (
    <Card className="p-6 border-2 border-accent bg-accent/10 neon-glow animate-pulse">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <Bell className="w-6 h-6 text-accent" />
          <div>
            <h3 className="text-lg font-semibold text-primary">Enable Reminder Notifications</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Allow JARVIS to send you push notifications for reminders
            </p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onDismiss}
          className="hover:bg-accent/20"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>

      <div className="space-y-3 mb-4">
        <div className="flex items-start gap-2 text-sm text-muted-foreground">
          <span className="text-accent">•</span>
          <span>Receive push notifications when reminders trigger</span>
        </div>
        <div className="flex items-start gap-2 text-sm text-muted-foreground">
          <span className="text-accent">•</span>
          <span>Hear audio beep alerts and TTS announcements</span>
        </div>
        <div className="flex items-start gap-2 text-sm text-muted-foreground">
          <span className="text-accent">•</span>
          <span>Works best while the app remains open (PWA limitation)</span>
        </div>
      </div>

      <Button
        onClick={handleRequestPermission}
        disabled={isRequesting}
        className="w-full bg-accent hover:bg-accent/90"
      >
        {isRequesting ? 'Requesting...' : 'Enable Notifications'}
      </Button>
    </Card>
  );
};

export default NotificationPermissionPrompt;
