// Question management interface with CRUD operations, search, and categorization
// Provides sleek UI for adding, editing, deleting, and organizing questions

import { useState, useEffect } from 'react';
import { Search, Plus, Edit, Trash2, Star, Tag, Download, Upload, Shuffle, Clock, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { QuestionDatabase, type Question, type Category } from '../lib/QuestionDatabase';

interface QuestionManagerProps {
  onQuestionSelect?: (question: Question) => void;
}

const QuestionManager = ({ onQuestionSelect }: QuestionManagerProps) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredQuestions, setFilteredQuestions] = useState<Question[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [newQuestion, setNewQuestion] = useState({ question: '', answer: '', categories: [] as string[] });
  const [viewMode, setViewMode] = useState<'all' | 'favorites' | 'recent'>('all');

  useEffect(() => {
    loadQuestions();
    loadCategories();
  }, []);

  useEffect(() => {
    filterQuestions();
  }, [questions, searchQuery, selectedCategory, viewMode]);

  const loadQuestions = async () => {
    try {
      const allQuestions = await QuestionDatabase.getAllQuestions();
      setQuestions(allQuestions);
    } catch (error) {
      console.error('Error loading questions:', error);
      toast.error('Failed to load questions');
    }
  };

  const loadCategories = async () => {
    try {
      const allCategories = await QuestionDatabase.getAllCategories();
      setCategories(allCategories);
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  };

  const filterQuestions = async () => {
    let filtered = questions;

    // Filter by view mode
    if (viewMode === 'favorites') {
      filtered = await QuestionDatabase.getFavoriteQuestions();
    } else if (viewMode === 'recent') {
      filtered = await QuestionDatabase.getRecentHistory(20);
    }

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(q => q.categories.includes(selectedCategory));
    }

    // Filter by search query
    if (searchQuery) {
      const lower = searchQuery.toLowerCase();
      filtered = filtered.filter(
        q =>
          q.question.toLowerCase().includes(lower) ||
          q.answer.toLowerCase().includes(lower) ||
          q.categories.some(c => c.toLowerCase().includes(lower))
      );
    }

    setFilteredQuestions(filtered);
  };

  const handleAddQuestion = async () => {
    if (!newQuestion.question.trim() || !newQuestion.answer.trim()) {
      toast.error('Question and answer are required');
      return;
    }

    try {
      await QuestionDatabase.addQuestion({
        question: newQuestion.question,
        answer: newQuestion.answer,
        categories: newQuestion.categories,
        isFavorite: false,
      });

      toast.success('Question added successfully');
      setNewQuestion({ question: '', answer: '', categories: [] });
      setIsAddDialogOpen(false);
      loadQuestions();
    } catch (error) {
      console.error('Error adding question:', error);
      toast.error('Failed to add question');
    }
  };

  const handleEditQuestion = async () => {
    if (!editingQuestion) return;

    try {
      await QuestionDatabase.updateQuestion(editingQuestion.id, {
        question: editingQuestion.question,
        answer: editingQuestion.answer,
        categories: editingQuestion.categories,
      });

      toast.success('Question updated successfully');
      setIsEditDialogOpen(false);
      setEditingQuestion(null);
      loadQuestions();
    } catch (error) {
      console.error('Error updating question:', error);
      toast.error('Failed to update question');
    }
  };

  const handleDeleteQuestion = async (id: string) => {
    if (!confirm('Are you sure you want to delete this question?')) return;

    try {
      await QuestionDatabase.deleteQuestion(id);
      toast.success('Question deleted successfully');
      loadQuestions();
    } catch (error) {
      console.error('Error deleting question:', error);
      toast.error('Failed to delete question');
    }
  };

  const handleToggleFavorite = async (id: string) => {
    try {
      await QuestionDatabase.toggleFavorite(id);
      loadQuestions();
    } catch (error) {
      console.error('Error toggling favorite:', error);
      toast.error('Failed to update favorite');
    }
  };

  const handleRandomQuestion = async () => {
    try {
      const random = await QuestionDatabase.getRandomQuestion();
      if (random) {
        if (onQuestionSelect) {
          onQuestionSelect(random);
        }
        toast.success('Random question selected');
      } else {
        toast.info('No questions available');
      }
    } catch (error) {
      console.error('Error getting random question:', error);
      toast.error('Failed to get random question');
    }
  };

  const handleExport = async () => {
    try {
      const data = await QuestionDatabase.exportData();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `jarvis-questions-${Date.now()}.json`;
      link.click();
      toast.success('Questions exported successfully');
    } catch (error) {
      console.error('Error exporting questions:', error);
      toast.error('Failed to export questions');
    }
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        await QuestionDatabase.importData(data);
        toast.success('Questions imported successfully');
        loadQuestions();
        loadCategories();
      } catch (error) {
        console.error('Error importing questions:', error);
        toast.error('Failed to import questions');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-primary">Question Database</h2>
          <p className="text-sm text-muted-foreground">{questions.length} questions stored</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleRandomQuestion} variant="outline" size="sm">
            <Shuffle className="w-4 h-4 mr-2" />
            Random
          </Button>
          <Button onClick={handleExport} variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button variant="outline" size="sm" asChild>
            <label>
              <Upload className="w-4 h-4 mr-2" />
              Import
              <input type="file" accept=".json" onChange={handleImport} className="hidden" />
            </label>
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                Add Question
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl bg-card border-primary/20">
              <DialogHeader>
                <DialogTitle className="text-primary">Add New Question</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="new-question">Question</Label>
                  <Input
                    id="new-question"
                    value={newQuestion.question}
                    onChange={(e) => setNewQuestion({ ...newQuestion, question: e.target.value })}
                    placeholder="Enter your question..."
                    className="mt-2 border-primary/20"
                  />
                </div>
                <div>
                  <Label htmlFor="new-answer">Answer</Label>
                  <Textarea
                    id="new-answer"
                    value={newQuestion.answer}
                    onChange={(e) => setNewQuestion({ ...newQuestion, answer: e.target.value })}
                    placeholder="Enter the answer..."
                    rows={5}
                    className="mt-2 border-primary/20"
                  />
                </div>
                <div>
                  <Label>Categories (comma-separated)</Label>
                  <Input
                    value={newQuestion.categories.join(', ')}
                    onChange={(e) =>
                      setNewQuestion({
                        ...newQuestion,
                        categories: e.target.value.split(',').map(c => c.trim()).filter(c => c),
                      })
                    }
                    placeholder="e.g., General, Technical, Personal"
                    className="mt-2 border-primary/20"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddQuestion} className="bg-primary hover:bg-primary/90">
                  Add Question
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* View Mode Tabs */}
      <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as any)}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="all">All Questions</TabsTrigger>
          <TabsTrigger value="favorites">Favorites</TabsTrigger>
          <TabsTrigger value="recent">Recent</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Search and Filter */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search questions..."
            className="pl-10 border-primary/20"
          />
        </div>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-[200px] border-primary/20">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map((cat) => (
              <SelectItem key={cat.id} value={cat.name}>
                {cat.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Questions List */}
      <ScrollArea className="h-[500px] border border-primary/20 rounded-lg p-4">
        {filteredQuestions.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No questions found</p>
            <Button onClick={() => setIsAddDialogOpen(true)} variant="outline" className="mt-4">
              <Plus className="w-4 h-4 mr-2" />
              Add Your First Question
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredQuestions.map((q) => (
              <div
                key={q.id}
                className="p-4 rounded-lg border border-primary/10 bg-card/50 hover:bg-card transition-colors"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold text-primary">{q.question}</h3>
                      {q.isFavorite && <Star className="w-4 h-4 text-accent fill-accent" />}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{q.answer}</p>
                    <div className="flex items-center gap-2 flex-wrap">
                      {q.categories.map((cat, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          <Tag className="w-3 h-3 mr-1" />
                          {cat}
                        </Badge>
                      ))}
                      {q.accessCount > 0 && (
                        <Badge variant="outline" className="text-xs">
                          <Clock className="w-3 h-3 mr-1" />
                          {q.accessCount} views
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleToggleFavorite(q.id)}
                      className="h-8 w-8"
                    >
                      <Star className={`w-4 h-4 ${q.isFavorite ? 'fill-accent text-accent' : ''}`} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setEditingQuestion(q);
                        setIsEditDialogOpen(true);
                      }}
                      className="h-8 w-8"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteQuestion(q.id)}
                      className="h-8 w-8 hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl bg-card border-primary/20">
          <DialogHeader>
            <DialogTitle className="text-primary">Edit Question</DialogTitle>
          </DialogHeader>
          {editingQuestion && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-question">Question</Label>
                <Input
                  id="edit-question"
                  value={editingQuestion.question}
                  onChange={(e) =>
                    setEditingQuestion({ ...editingQuestion, question: e.target.value })
                  }
                  className="mt-2 border-primary/20"
                />
              </div>
              <div>
                <Label htmlFor="edit-answer">Answer</Label>
                <Textarea
                  id="edit-answer"
                  value={editingQuestion.answer}
                  onChange={(e) =>
                    setEditingQuestion({ ...editingQuestion, answer: e.target.value })
                  }
                  rows={5}
                  className="mt-2 border-primary/20"
                />
              </div>
              <div>
                <Label>Categories (comma-separated)</Label>
                <Input
                  value={editingQuestion.categories.join(', ')}
                  onChange={(e) =>
                    setEditingQuestion({
                      ...editingQuestion,
                      categories: e.target.value.split(',').map(c => c.trim()).filter(c => c),
                    })
                  }
                  className="mt-2 border-primary/20"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditQuestion} className="bg-primary hover:bg-primary/90">
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default QuestionManager;
