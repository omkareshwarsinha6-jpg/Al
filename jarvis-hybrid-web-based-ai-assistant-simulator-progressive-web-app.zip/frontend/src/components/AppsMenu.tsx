// Apps menu component with tappable icons for top 20 most used intents
// Provides quick access to frequently used applications with direct Android app launching

import { useState } from 'react';
import { X, ExternalLink, Smartphone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { OfflineCommandEngine, IntentEngine } from '../lib/OfflineCommandEngine';
import { toast } from 'sonner';

interface AppsMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onAppLaunch: (appKey: string, appName: string, intentUrl: string) => void;
}

const AppsMenu = ({ isOpen, onClose, onAppLaunch }: AppsMenuProps) => {
  const [engine] = useState(() => new OfflineCommandEngine());
  const topApps = engine.getTopApps();

  // Handle app click
  const handleAppClick = (app: { key: string; name: string; package: string; webUrl: string }) => {
    const { intentUrl, webFallbackUrl } = IntentEngine.generateAppIntent(app.package, app.webUrl);
    const finalUrl = intentUrl || webFallbackUrl;
    onAppLaunch(app.key, app.name, finalUrl);
    toast.success(`Opening ${app.name}`);
  };

  // Get app icon emoji based on app key
  const getAppIcon = (key: string): string => {
    const icons: { [key: string]: string } = {
      'whatsapp': '💬',
      'youtube': '▶️',
      'instagram': '📷',
      'facebook': '👥',
      'gmail': '📧',
      'chrome': '🌐',
      'maps': '🗺️',
      'spotify': '🎵',
      'netflix': '🎬',
      'amazon': '🛒',
      'telegram': '✈️',
      'twitter': '🐦',
      'linkedin': '💼',
      'drive': '☁️',
      'photos': '🖼️',
      'paytm': '💳',
      'phonepe': '💰',
      'swiggy': '🍔',
      'zomato': '🍕',
      'uber': '🚗',
    };
    return icons[key] || '📱';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] bg-card border-primary/20">
        <DialogHeader>
          <DialogTitle className="text-primary flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            Quick App Launcher
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="h-[500px] pr-4">
          <div className="grid grid-cols-4 gap-4">
            {topApps.map((app) => (
              <button
                key={app.key}
                onClick={() => handleAppClick(app)}
                className="flex flex-col items-center gap-2 p-4 rounded-lg border border-primary/20 bg-card/50 hover:bg-primary/10 hover:border-primary/40 transition-all group"
              >
                <div className="text-4xl">{getAppIcon(app.key)}</div>
                <span className="text-xs text-center text-muted-foreground group-hover:text-primary transition-colors">
                  {app.name}
                </span>
              </button>
            ))}
          </div>

          <div className="mt-6 p-4 rounded-lg bg-accent/10 border border-accent/20">
            <h4 className="text-sm font-semibold text-accent mb-2">How to use:</h4>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Tap any app icon to launch directly</li>
              <li>• Apps open via native Android intents</li>
              <li>• Works best on Android devices and WebView</li>
              <li>• Falls back to web version if app not installed</li>
            </ul>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};

export default AppsMenu;
