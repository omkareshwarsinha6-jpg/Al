// Neon-styled loading screen component for smooth transitions
// Displays JARVIS logo with animated pulse and loading text
// Used during app initialization and state transitions

import { Loader2 } from 'lucide-react';

interface LoadingScreenProps {
  message?: string;
}

const LoadingScreen = ({ message = 'Initializing JARVIS...' }: LoadingScreenProps) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 flex items-center justify-center">
      <div className="text-center">
        {/* JARVIS logo with pulse animation */}
        <img 
          src="/assets/generated/jarvis-logo-transparent.dim_200x200.png" 
          alt="JARVIS" 
          className="w-24 h-24 mx-auto mb-4 animate-pulse" 
          onError={(e) => {
            // Fallback if image fails to load
            e.currentTarget.style.display = 'none';
          }}
        />
        
        {/* Animated spinner */}
        <Loader2 className="w-12 h-12 mx-auto mb-4 text-primary animate-spin" />
        
        {/* Loading text with neon effect */}
        <p className="text-primary neon-text text-xl">{message}</p>
        
        {/* Subtle hint text */}
        <p className="text-muted-foreground text-sm mt-2">
          Please wait while we prepare your AI assistant...
        </p>
      </div>
    </div>
  );
};

export default LoadingScreen;
