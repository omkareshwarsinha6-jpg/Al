// Developer logs panel for visual inspection of command and automation flows
// Provides detailed logging with filtering and export capabilities

import { useState } from 'react';
import { Terminal, Download, Trash2, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

interface LogEntry {
  timestamp: number;
  type: 'command' | 'automation' | 'error' | 'info' | 'intent' | 'memory';
  message: string;
}

interface DeveloperLogsProps {
  logs: LogEntry[];
  onClear: () => void;
}

const DeveloperLogs = ({ logs, onClear }: DeveloperLogsProps) => {
  const [filter, setFilter] = useState<string>('all');

  // Filter logs based on selected type
  const filteredLogs = filter === 'all' 
    ? logs 
    : logs.filter(log => log.type === filter);

  // Export logs to JSON
  const exportLogs = () => {
    const dataStr = JSON.stringify(logs, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `jarvis-logs-${Date.now()}.json`;
    link.click();
    toast.success('Logs exported');
  };

  // Get badge color based on log type
  const getBadgeVariant = (type: string): 'default' | 'destructive' | 'outline' => {
    switch (type) {
      case 'error':
        return 'destructive';
      case 'command':
      case 'automation':
        return 'default';
      default:
        return 'outline';
    }
  };

  // Get badge icon based on log type
  const getTypeIcon = (type: string): string => {
    switch (type) {
      case 'command':
        return '💬';
      case 'automation':
        return '⚡';
      case 'error':
        return '❌';
      case 'info':
        return 'ℹ️';
      case 'intent':
        return '📱';
      case 'memory':
        return '🧠';
      default:
        return '📝';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Terminal className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold text-primary">Developer Logs</h3>
          <Badge variant="outline">{filteredLogs.length} entries</Badge>
        </div>

        <div className="flex items-center gap-2">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[140px] border-primary/20">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Logs</SelectItem>
              <SelectItem value="command">Commands</SelectItem>
              <SelectItem value="automation">Automations</SelectItem>
              <SelectItem value="intent">Intents</SelectItem>
              <SelectItem value="memory">Memory</SelectItem>
              <SelectItem value="error">Errors</SelectItem>
              <SelectItem value="info">Info</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" size="sm" onClick={exportLogs}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>

          <Button variant="outline" size="sm" onClick={onClear} className="text-destructive hover:text-destructive">
            <Trash2 className="w-4 h-4 mr-2" />
            Clear
          </Button>
        </div>
      </div>

      <ScrollArea className="h-[400px] rounded-lg border border-primary/20 bg-card/50 p-4">
        {filteredLogs.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Terminal className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No logs to display</p>
          </div>
        ) : (
          <div className="space-y-2 font-mono text-xs">
            {filteredLogs.map((log, index) => (
              <div
                key={index}
                className="flex items-start gap-3 p-2 rounded border border-primary/10 hover:bg-primary/5 transition-colors"
              >
                <span className="text-lg flex-shrink-0">{getTypeIcon(log.type)}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant={getBadgeVariant(log.type)} className="text-xs">
                      {log.type}
                    </Badge>
                    <span className="text-muted-foreground">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-foreground break-words">{log.message}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
};

export default DeveloperLogs;
