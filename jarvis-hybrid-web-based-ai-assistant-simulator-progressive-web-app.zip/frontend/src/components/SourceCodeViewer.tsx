// Read-only source code viewer component for admin users
// Displays simplified code snippets in tabbed interface
// Shows App.tsx, JarvisInterface.tsx, and backend main.mo

import { useState } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileCode, FileText } from 'lucide-react';

const SourceCodeViewer = () => {
  // Track currently selected file tab
  const [selectedFile, setSelectedFile] = useState('app');

  // File content map with simplified code snippets
  const files = {
    app: {
      name: 'App.tsx',
      language: 'typescript',
      content: `// Main application component with authentication flow
// Manages three states: authentication, profile setup, main interface
// Uses Internet Identity for auth and React Query for data

import { useState, useEffect } from 'react';
import { ThemeProvider } from 'next-themes';
import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useGetCallerUserProfile } from './hooks/useQueries';
import AuthenticationPage from './pages/AuthenticationPage';
import ProfileSetup from './components/ProfileSetup';
import JarvisInterface from './components/JarvisInterface';

function App() {
  // Get authentication state
  const { identity, isInitializing } = useInternetIdentity();
  const { data: userProfile, isLoading, isFetched } = useGetCallerUserProfile();
  
  // Determine which screen to show
  const isAuthenticated = !!identity;
  const showProfileSetup = isAuthenticated && !isLoading && isFetched && !userProfile;
  const showMainInterface = isAuthenticated && !isLoading && isFetched && userProfile;

  // Show loading screen during initialization
  if (isInitializing || (isAuthenticated && isLoading)) {
    return <LoadingScreen />;
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="dark">
      {!isAuthenticated && <AuthenticationPage />}
      {showProfileSetup && <ProfileSetup />}
      {showMainInterface && <JarvisInterface userProfile={userProfile} />}
    </ThemeProvider>
  );
}`,
    },
    interface: {
      name: 'JarvisInterface.tsx',
      language: 'typescript',
      content: `// Core JARVIS voice assistant interface
// Features: Continuous speech recognition, text-to-speech
// Integrations: Google Search, Wikipedia API, DeepSeek AI
// Custom commands: User-defined voice triggers

// Key functionality:
// - Voice recognition using Web Speech API (en-IN locale)
// - Auto-restart recognition when user stops speaking
// - Command processing: greetings, time, search, apps
// - Custom commands stored per user in backend
// - Admin-only source code viewer access

// Command patterns:
// - "search X on Google" → Google search
// - "search X on Wikipedia" → Wikipedia summary
// - "what is X" → Wikipedia lookup
// - "open YouTube" → Launch app
// - "open YouTube and search X" → App + search
// - Custom trigger phrases → Custom responses

// State management:
// - Messages: Chat history with User/Jarvis speakers
// - Listening: Voice recognition active state
// - Transcript: Live voice input display
// - Custom commands: User-defined triggers/actions
// - API key: DeepSeek integration (optional)`,
    },
    backend: {
      name: 'main.mo',
      language: 'motoko',
      content: `// Backend canister for JARVIS application
// Manages user data, authentication, and storage

// Type definitions:
// - UserProfile: name, role (admin/guest), loginTimestamp
// - CustomCommand: triggerPhrase, action
// - ConversationEntry: speaker, message, timestamp

// Storage:
// - userProfiles: Map<Principal, UserProfile>
// - apiKeys: Map<Principal, Text>
// - conversationHistories: Map<Principal, [ConversationEntry]>
// - customCommands: Map<Principal, [CustomCommand]>

// Access control:
// - Admin: Full access, source code viewer
// - User: Standard features, data storage
// - Guest: Basic features, no persistence

// Key functions:
// - saveCallerUserProfile: Store user profile
// - getCallerUserProfile: Retrieve user profile
// - storeApiKey: Save DeepSeek API key
// - saveCustomCommands: Store voice commands
// - storeConversationHistory: Save chat history
// - isCallerAdmin: Check admin status`,
    },
  };

  return (
    <div className="space-y-4">
      {/* Tabbed interface for file selection */}
      <Tabs value={selectedFile} onValueChange={setSelectedFile} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-background/50">
          {/* App.tsx tab */}
          <TabsTrigger value="app" className="data-[state=active]:bg-primary/20">
            <FileCode className="w-4 h-4 mr-2" />
            App.tsx
          </TabsTrigger>
          {/* JarvisInterface.tsx tab */}
          <TabsTrigger value="interface" className="data-[state=active]:bg-primary/20">
            <FileCode className="w-4 h-4 mr-2" />
            Interface
          </TabsTrigger>
          {/* Backend main.mo tab */}
          <TabsTrigger value="backend" className="data-[state=active]:bg-primary/20">
            <FileText className="w-4 h-4 mr-2" />
            Backend
          </TabsTrigger>
        </TabsList>

        {/* Tab content for each file */}
        {Object.entries(files).map(([key, file]) => (
          <TabsContent key={key} value={key} className="mt-4">
            <div className="rounded-lg border border-primary/20 bg-background/50 overflow-hidden">
              {/* File name header */}
              <div className="px-4 py-2 bg-primary/10 border-b border-primary/20">
                <p className="text-sm font-mono text-primary">{file.name}</p>
              </div>
              {/* Scrollable code content */}
              <ScrollArea className="h-[400px]">
                <pre className="p-4 text-sm font-mono text-foreground">
                  <code>{file.content}</code>
                </pre>
              </ScrollArea>
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Footer note */}
      <div className="text-xs text-muted-foreground text-center">
        <p>Read-only source code view for admin users</p>
      </div>
    </div>
  );
};

export default SourceCodeViewer;
