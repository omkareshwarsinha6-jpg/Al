import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { ConversationEntry } from '../backend';

export function useGetApiKey() {
  const { actor, isFetching } = useActor();

  return useQuery<string | null>({
    queryKey: ['apiKey'],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getApiKey();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useStoreApiKey() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (apiKey: string) => {
      if (!actor) throw new Error('Actor not initialized');
      return actor.storeApiKey(apiKey);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['apiKey'] });
    },
  });
}

export function useGetConversationHistory() {
  const { actor, isFetching } = useActor();

  return useQuery<ConversationEntry[]>({
    queryKey: ['conversationHistory'],
    queryFn: async () => {
      if (!actor) return [];
      try {
        return await actor.getConversationHistory();
      } catch (error) {
        // Return empty array if no history found
        return [];
      }
    },
    enabled: !!actor && !isFetching,
  });
}

export function useStoreConversationHistory() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (history: ConversationEntry[]) => {
      if (!actor) throw new Error('Actor not initialized');
      return actor.storeConversationHistory(history);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['conversationHistory'] });
    },
  });
}
