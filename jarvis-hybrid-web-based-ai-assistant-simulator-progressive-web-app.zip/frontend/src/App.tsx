import { useState } from 'react';
import { ThemeProvider } from 'next-themes';
import { Toaster } from '@/components/ui/sonner';
import JarvisInterface from './components/JarvisInterface';

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false} forcedTheme="dark">
      <div className="min-h-screen bg-background">
        <JarvisInterface />
        <Toaster />
      </div>
    </ThemeProvider>
  );
}

export default App;
